<script setup>
import NoticeTable from "@/components/board/NoticeTable.vue";
</script>

<template>
  <div class="NoticeView">
    <NoticeTable />
  </div>
</template>

<style scoped>
.NoticeView {
  width: 1400px;
}
</style>
