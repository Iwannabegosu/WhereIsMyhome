export const imgRegex = /<img[^>]+>/g; // 이미지 여러개 확인/g

// .match() 일치하는 것들 배열로 만들기
// .exec() 일치하는 것들 중 첫번째