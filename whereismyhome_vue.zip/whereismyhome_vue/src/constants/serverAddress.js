export const LOCAl_ADDRESS = "localhost:8080/home";

export default function getServerAddress() {
  return LOCAl_ADDRESS;
}
