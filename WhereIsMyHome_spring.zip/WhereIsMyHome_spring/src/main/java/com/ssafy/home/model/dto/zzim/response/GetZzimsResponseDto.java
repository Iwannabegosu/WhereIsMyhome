package com.ssafy.home.model.dto.zzim.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GetZzimsResponseDto {
	private int zzimTbId;
	private int userId;
	private double lat;
	private double lng;
	private String className;
	private double excluUseAr;
	private double dealAmount;
	private String sidoName;
	private String gugunName;
	private String dongName;
	private String aptName;
	private double pyung;
}
