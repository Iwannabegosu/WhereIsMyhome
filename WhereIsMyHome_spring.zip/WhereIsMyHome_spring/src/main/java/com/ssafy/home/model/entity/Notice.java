package com.ssafy.home.model.entity;

import java.time.LocalDateTime;

import com.ssafy.home.model.dto.notice.response.NoticeDetatilResponseDto;
import com.ssafy.home.model.dto.notice.response.NoticeListAllResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Notice {
	private int noticeId;
	private String title;
	private String content;
	private int userId;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	
	private User user;
	public NoticeListAllResponseDto toNoticeDto() {
		return NoticeListAllResponseDto
				.builder()
				.noticeId(noticeId)
				.userId(userId)
				.title(title)
				.content(content)
				.createDate(createDate)
				.updateDate(updateDate)
				.id(user.getId())
				.email(user.getEmail())
				.profileImgeUrl(user.getProfileImgUrl())
				.nickname(user.getNickname())
				.build();
	}
	public NoticeDetatilResponseDto toDetailDto() {
		return NoticeDetatilResponseDto
				.builder()
				.noticeId(noticeId)
				.userId(userId)
				.title(title)
				.content(content)
				.createDate(createDate)
				.updateDate(updateDate)
				.id(user.getId())
				.email(user.getEmail())
				.profileImgeUrl(user.getProfileImgUrl())
				.nickname(user.getNickname())
				.build();
	}
	
}
