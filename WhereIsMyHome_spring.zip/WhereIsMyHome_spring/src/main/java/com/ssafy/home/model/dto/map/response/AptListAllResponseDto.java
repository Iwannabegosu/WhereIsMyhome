package com.ssafy.home.model.dto.map.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AptListAllResponseDto {
	private String latitude;
	private String longitude;
}
