package com.ssafy.home.model.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.home.model.dto.map.request.LocationRequestDto;
import com.ssafy.home.model.dto.map.response.AptListAllResponseDto;
import com.ssafy.home.model.dto.map.response.DoResponseDto;
import com.ssafy.home.model.dto.map.response.DongResponseDto;
import com.ssafy.home.model.dto.map.response.LocationResponseDto;
import com.ssafy.home.model.dto.map.response.SigunguResponseDto;
import com.ssafy.home.model.entity.Apt;
import com.ssafy.home.model.entity.Boundary;
import com.ssafy.home.model.entity.Dong;
import com.ssafy.home.model.entity.Sigungu;
import com.ssafy.home.model.mapper.AptMapper;

@Service
public class MapServiceImpl implements MapService{

	@Autowired
	private AptMapper mapper;
	
	@Override
	public List<AptListAllResponseDto> listAll() {
		List<Apt> list = mapper.listAll();
		return list.stream().map(Apt::toAptDto).collect(Collectors.toList());
		
	}

	@Override
	public List<LocationResponseDto> location(LocationRequestDto dto) {
		List<Apt> list = mapper.location(dto);
		return list.stream().map(Apt::toLocDto).collect(Collectors.toList());
	}

	@Override
	public List<DoResponseDto> cluster(LocationRequestDto dto) {
		List<Boundary> list = mapper.cluster(dto);
		return list.stream().map(Boundary::toDoResponseDto).collect(Collectors.toList());
	}

	@Override
	public List<SigunguResponseDto> sigungu(LocationRequestDto dto) {
		List<Sigungu> list = mapper.sigungu(dto);
		return list.stream().map(Sigungu::toSigunguDto).collect(Collectors.toList());
	}

	@Override
	public List<DongResponseDto> dong(LocationRequestDto dto) {
		List<Dong> list = mapper.dong(dto);
		return list.stream().map(Dong::toDongDto).collect(Collectors.toList());
	}

	@Override
	public List<LocationResponseDto> search(String word) {
		List<Apt> list = mapper.search(word);
		return list.stream().map(Apt::toLocDto).collect(Collectors.toList());
	}
}
