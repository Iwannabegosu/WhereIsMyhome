package com.ssafy.home.model.dto.board.request;

import com.ssafy.home.model.entity.Comment;

import lombok.Data;

@Data
public class BoardCommentRequestDto {
	private int boardId;
	private int userId;
	private String content;
	
	public Comment toEntity() {
		return Comment
			   .builder()
			   .boardId(boardId)
			   .userId(userId)
			   .content(content)
			   .build();
	}
}
