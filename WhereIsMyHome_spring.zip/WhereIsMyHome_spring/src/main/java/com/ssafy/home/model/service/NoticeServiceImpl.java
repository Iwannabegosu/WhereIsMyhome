package com.ssafy.home.model.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.home.model.dto.notice.request.NoticeUpdateDto;
import com.ssafy.home.model.dto.notice.request.NoticeWriteRequestDto;
import com.ssafy.home.model.dto.notice.response.NoticeDetatilResponseDto;
import com.ssafy.home.model.dto.notice.response.NoticeListAllResponseDto;
import com.ssafy.home.model.entity.Notice;
import com.ssafy.home.model.mapper.NoticeMapper;

@Service
public class NoticeServiceImpl implements NoticeService{
	@Autowired
	NoticeMapper mapper;

	@Override
	public boolean post(NoticeWriteRequestDto dto) {
		int n = mapper.post(dto.toNoticeEntity());
		if(n>0) return true;
		else return false;
	}

	@Override
	public boolean delNotice(int noticeId) {
		int n = mapper.delNotice(noticeId);
		if(n>0) return true;
		else return false;
	}

	@Override
	public List<NoticeListAllResponseDto> getListAll(int page) {
		int count = 15;
		int offset = (page - 1) * count;
		List<Notice> list = mapper.getListAll(count, offset);
		return list.stream().map(Notice::toNoticeDto).collect(Collectors.toList());
	}

	@Override
	public int getNoticeCount() {
		return mapper.getNoticeCount();
	}

	@Override
	public List<NoticeListAllResponseDto> getSearchList(int page, String word) {
		int count = 15;
		int offset = (page - 1) * count;
		List<Notice> list = mapper.getSearchList(count, offset, word);
		return list.stream().map(Notice::toNoticeDto).collect(Collectors.toList());
	}

	@Override
	public int getSearchCount(String word) {
		return mapper.getSearchCount(word);
	}

	@Override
	public NoticeDetatilResponseDto getNotice(int noticeId) {
		return mapper.getNotice(noticeId).toDetailDto();
	}

	@Override
	public boolean updateNotice(int noticeId, NoticeUpdateDto dto) {
		Notice entity = dto.toNoticeEntity();
		entity.setNoticeId(noticeId);
		int n = mapper.updateNotice(entity);
		if(n > 0) return true;
		else return false;
	}

	@Override
	public List<NoticeListAllResponseDto> descNotice() {
		List<Notice> list = mapper.descNotice();
		return list.stream().map(Notice::toNoticeDto).collect(Collectors.toList());
	}
}
