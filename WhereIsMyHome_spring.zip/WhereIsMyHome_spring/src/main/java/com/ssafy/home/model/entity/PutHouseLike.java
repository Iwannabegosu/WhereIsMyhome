package com.ssafy.home.model.entity;

import com.ssafy.home.model.dto.puthouse.response.DetailLikeListResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PutHouseLike {
	private int putHouseLikeId;
	private int putHouseId;
	private int userId;
	
	public DetailLikeListResponseDto toDetailLikeListResponseDto() {
		return DetailLikeListResponseDto
				.builder()
				.putHouseLikeId(putHouseLikeId)
				.putHouseId(putHouseId)
				.userId(userId)
				.build();
	}
}
