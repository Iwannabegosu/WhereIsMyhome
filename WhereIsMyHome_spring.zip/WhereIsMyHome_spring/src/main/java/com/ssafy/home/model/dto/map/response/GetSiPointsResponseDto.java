package com.ssafy.home.model.dto.map.response;

public class GetSiPointsResponseDto {

}
