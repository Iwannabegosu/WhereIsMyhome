package com.ssafy.home.model.entity;

import com.ssafy.home.model.dto.puthouse.response.PutHouseBookmarkListResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PutHouseBookmark {
	private int putHouseBookmarkId;
	private int putHouseId;
	private int userId;
	
	public PutHouseBookmarkListResponseDto toPutHouseBookmarkListResponseDto() {
		return PutHouseBookmarkListResponseDto
				.builder()
				.userId(userId)
				.build();
	}
}
