package com.ssafy.home.model.service;

import java.util.List;

import com.ssafy.home.model.dto.map.request.LocationRequestDto;
import com.ssafy.home.model.dto.map.response.AptListAllResponseDto;
import com.ssafy.home.model.dto.map.response.DoResponseDto;
import com.ssafy.home.model.dto.map.response.DongResponseDto;
import com.ssafy.home.model.dto.map.response.LocationResponseDto;
import com.ssafy.home.model.dto.map.response.SigunguResponseDto;

public interface MapService {
	public List<AptListAllResponseDto> listAll();
	public List<LocationResponseDto> location(LocationRequestDto dto);
	public List<DoResponseDto> cluster(LocationRequestDto dto);
	public List<SigunguResponseDto> sigungu(LocationRequestDto dto);
	public List<DongResponseDto> dong(LocationRequestDto dto);
	public List<LocationResponseDto> search(String word);
}
