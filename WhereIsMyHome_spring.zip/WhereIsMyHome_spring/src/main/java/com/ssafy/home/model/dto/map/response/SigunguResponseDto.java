package com.ssafy.home.model.dto.map.response;

import com.ssafy.home.model.entity.Sigungu;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
public class SigunguResponseDto {
	private int sigunguId;
	private double average;
	private String sigunguName;
	private double lat;
	private double lng;
	private String className;
}
