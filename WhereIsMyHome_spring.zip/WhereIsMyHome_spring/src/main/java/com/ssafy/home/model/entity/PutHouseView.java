package com.ssafy.home.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PutHouseView {
	private int putHouseViewId;
	private int putHouseId;
	private int userId;
}
