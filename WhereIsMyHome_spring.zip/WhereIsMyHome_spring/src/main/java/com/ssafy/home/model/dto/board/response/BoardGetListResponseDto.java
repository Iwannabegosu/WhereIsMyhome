package com.ssafy.home.model.dto.board.response;
import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BoardGetListResponseDto {
	private int boardId;
	private String title;
	private String content;
	private int userId;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	private String id;
	private String email;
	private String profileImgUrl;
	private String nickname;
	
	private int commentCount;
	private int likeCount;
	private int viewCount;
	
	
}
