package com.ssafy.home.model.dto.puthouse.request;

import lombok.Data;

@Data
public class LikeRequestDto {
	private int userId;
}
