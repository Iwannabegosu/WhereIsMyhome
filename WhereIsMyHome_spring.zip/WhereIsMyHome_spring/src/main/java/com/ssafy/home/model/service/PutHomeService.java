package com.ssafy.home.model.service;

import java.util.List;

import com.ssafy.home.model.dto.puthouse.request.PutHouseBookmarkRequestDto;
import com.ssafy.home.model.dto.puthouse.request.DeleteCommentRequestDto;
import com.ssafy.home.model.dto.puthouse.request.DetailLikeListRequestDto;
import com.ssafy.home.model.dto.puthouse.request.LikeCancelRequestDto;
import com.ssafy.home.model.dto.puthouse.request.LikeRequestDto;
import com.ssafy.home.model.dto.puthouse.request.PostCommentRequestDto;
import com.ssafy.home.model.dto.puthouse.request.PutHouseBookmarkCancelRequestDto;
import com.ssafy.home.model.dto.puthouse.request.PutHouseBookmarkListRequestDto;
import com.ssafy.home.model.dto.puthouse.request.SearchPaginationRequestDto;
import com.ssafy.home.model.dto.puthouse.request.UpdateCommentRequestDto;
import com.ssafy.home.model.dto.puthouse.request.UpdateRequestDto;
import com.ssafy.home.model.dto.puthouse.request.ViewRequestDto;
import com.ssafy.home.model.dto.puthouse.request.WriteRequestDto;
import com.ssafy.home.model.dto.puthouse.response.DetailLikeListResponseDto;
import com.ssafy.home.model.dto.puthouse.response.DetailResponseDto;
import com.ssafy.home.model.dto.puthouse.response.ListAllResponseDto;
import com.ssafy.home.model.dto.puthouse.response.ListCommentResponseDto;
import com.ssafy.home.model.dto.puthouse.response.PutHouseBookmarkListResponseDto;
import com.ssafy.home.model.dto.puthouse.response.SearchListResponseDto;

public interface PutHomeService {
	public boolean write(WriteRequestDto writeRequestDto);
	public List<ListAllResponseDto> listAll(int page, int option);
	public List<SearchListResponseDto> searchList(int page, String word);
	public int pagination();
	public int searchPagination(SearchPaginationRequestDto searchPaginationRequestDto);
	public DetailResponseDto detail(int putHouseId);
	public boolean delete(int putHouseId);
	public boolean update(int putHouseId, UpdateRequestDto updateRequestDto);
	public boolean view(int putHouseId, ViewRequestDto viewRequestDto);
	public boolean like(int putHouseId, LikeRequestDto likeRequestDto);
	public List<DetailLikeListResponseDto> detailLikeList(DetailLikeListRequestDto detailLikeListRequestDto);
	public boolean likeCancel(int putHouseId, LikeCancelRequestDto likeCancelRequestDto);
	public boolean postComment(int putHouseId, PostCommentRequestDto postCommentRequestDto);
	public List<ListCommentResponseDto> listComment(int putHouseId);
	public boolean deleteComment(int putHouseId, DeleteCommentRequestDto deleteCommentRequestDto);
	public boolean updateComment(int putHouseId, UpdateCommentRequestDto updateCommentRequestDto);
	public boolean bookmark(int putHouseId, PutHouseBookmarkRequestDto putBookmarkRequestDto);
	public List<PutHouseBookmarkListResponseDto> bookmarkList(int putHouseId);
	public boolean bookmarkCancel(int putHouseId, PutHouseBookmarkCancelRequestDto putHouseBookmarkCancelRequestDto);
}
