package com.ssafy.home.model.entity;

import com.ssafy.home.model.dto.map.response.AptListAllResponseDto;
import com.ssafy.home.model.dto.map.response.LocationResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Apt {
	private String aptSeq; // primary key
	private String sggCd; //  지역 코드
	private String umdCd; // 동코드
	private String umdNm; // 동
	private String jibun;
	private String roadNmSggCd;
	private String roadNm;
	private String roadNmBonbun;
	private String roadNmbubun;
	private String aptNm; // 아파트 이름
	private String buildYear;
	private String latitude; // 위도
	private String longitude; // 경도
	private String className; // 클래스네임
	
	private HouseDeals houseDeals;
	private DongCodes dongCodes;
	
	public AptListAllResponseDto toAptDto() {
		return AptListAllResponseDto
				.builder()
				.latitude(latitude)
				.longitude(longitude)
				.build();
	}
	public LocationResponseDto toLocDto() {
		String str = houseDeals.getDealAmount();
		str = str.replace(",", "");
		 double number = Double.parseDouble(str);
		 double result = number / 10000;
	     result = Math.round(result * 10.0) / 10.0;
		return LocationResponseDto
				.builder()
				.lat(Double.parseDouble(latitude))
				.lng(Double.parseDouble(longitude))
				.className(className)
				.excluUseAr(houseDeals.getExcluUseAr())
				.dealAmount(result)
				.pyung((int) Math.round(houseDeals.getExcluUseAr() / 3.3))
				.sidoName(dongCodes.getSidoName())
				.gugunName(dongCodes.getGugunName())
				.dongName(dongCodes.getDongName())
				.aptName(aptNm)
				.aptSeq(str)
				.build();
	}
	
}
