package com.ssafy.home.model.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.home.model.dto.zzim.request.PostZzimRequestDto;
import com.ssafy.home.model.dto.zzim.response.GetZzimsResponseDto;
import com.ssafy.home.model.entity.Zzim;
import com.ssafy.home.model.mapper.ZzimMapper;


@Service
public class ZzimServiceImpl implements ZzimService {

	
	@Autowired
	ZzimMapper mapper;
	
	@Override
	public boolean postZzim(PostZzimRequestDto dto) {
		int cnt = mapper.postZzim(dto.toEntity());
		return cnt == 1;
	}

	@Override
	public boolean deleteZzim(String lat, String lng, int userId) {
		int cnt = mapper.deleteZzim(lat, lng, userId);
		return cnt == 1;
	}

	@Override
	public List<GetZzimsResponseDto> getZzims(int userId) {
		List<Zzim> zzims = mapper.getZzims(userId);
		return zzims.stream().map(Zzim::toGetZzimsResponseDto).collect(Collectors.toList());
	}

}
