package com.ssafy.home.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ssafy.home.model.entity.PutHouse;
import com.ssafy.home.model.entity.PutHouseBookmark;
import com.ssafy.home.model.entity.PutHouseComment;
import com.ssafy.home.model.entity.PutHouseLike;

@Mapper
public interface PutHouseMapper {
	public int write(PutHouse putHouse);
	public List<PutHouse> listAll(@Param("offset") int offset, @Param("count") int count, @Param("option") int option);
	public List<PutHouse> searchList(@Param("offset") int offset, @Param("count") int count, @Param("word") String word);
	
	// 페이지 네이션
	public int pagination();
	public int searchPagination(String word);
	
	public PutHouse detail(int putHouseId);
	public int delete(int putHouseId);
	public int update(PutHouse putHouse);
	public int view(@Param("putHouseId") int putHouseId, @Param("userId") int userId);
	public int like(@Param("putHouseId") int putHouseId, @Param("userId") int userId);
	public List<PutHouseLike> detailLikeList(int putHouseId);
	public int likeCancel(@Param("putHouseId") int putHouseId, @Param("userId") int userId);
	public int postComment(PutHouseComment putHouseComment);
	public List<PutHouseComment> listComment(int putHouseId);
	public int deleteComment(int putHouseCommentId);
	public int updateComment(PutHouseComment putHouseComment);
	public int bookmark(@Param("putHouseId") int putHouseId, @Param("userId") int userId);
	public List<PutHouseBookmark> bookmarkList(int putHouseId);
	public int bookmarkCancel(@Param("putHouseId") int putHouseId, @Param("userId") int userId);
	
}
