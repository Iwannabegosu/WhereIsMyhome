package com.ssafy.home.jwt;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;


import com.ssafy.home.model.entity.User;
import com.ssafy.home.model.mapper.UserMapper;
import com.ssafy.home.security.PrincipalUser;

import java.security.Key;
import java.util.Collection;
import java.util.Date;

@Component
public class JwtProvider {
	
    private final Key key;
    private UserMapper userMapper;
    
    public JwtProvider(@Value("${jwt.secret}") String secret, @Autowired UserMapper userMapper) {
        key = Keys.hmacShaKeyFor(Decoders.BASE64.decode(secret));
        this.userMapper = userMapper;
    }
    
    public String generateToken(User user) {
        int userId = user.getUserId();
        String id = user.getId();
        Collection<? extends GrantedAuthority> authorities = user.getAuthorities();
        
        Date expireDate = new Date(new Date().getTime() + (1000 * 60 * 60 * 24));
        String accessToken = Jwts
                .builder()
                .claim("userId", userId)
                .claim("id", id)
                .claim("authorities", authorities)
                .setExpiration(expireDate)
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
        return accessToken;
    }
    
    public String removeBearer(String token) {
        if(!StringUtils.hasText(token)) {
            return null;
        }
        return token.substring("Bearer ".length());
    }

    public Claims getClaims(String token) {
        Claims claims = null;

            claims = Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(token)
                    .getBody();

        return claims;
    }

    public Authentication getAuthentication(Claims claims) {
        String id = claims.get("id").toString();
        User user = userMapper.findUserById(id);
        if(user == null) {
            // 토큰은 유효하지만 DB 에서 USER 정보가 삭제되었을 경우
            return null;
        }
        PrincipalUser principalUser = user.toPrincipalUser();
        return new UsernamePasswordAuthenticationToken(principalUser, principalUser.getPassword(), principalUser.getAuthorities());
    }
}
