package com.ssafy.home.model.dto.puthouse.request;

import lombok.Data;

@Data
public class SearchPaginationRequestDto {
	private String word;
}
