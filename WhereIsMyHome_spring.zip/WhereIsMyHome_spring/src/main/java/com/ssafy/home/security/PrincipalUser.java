package com.ssafy.home.security;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class PrincipalUser implements UserDetails {
    private int userId;
    private String id;        // 사용자 ID
    private String email;     // 이메일
    private List<SimpleGrantedAuthority> authorities;

    @Override
    public String getPassword() {
        return ""; // 비밀번호 필요 시 구현
    }

    @Override
    public String getUsername() {
        return this.id; // 아이디를 반환하도록 설정
    }

    // 계정 사용기간 만료
    @Override
    public boolean isAccountNonExpired() {
        return false;
    }

    // 계정 잠금
    @Override
    public boolean isAccountNonLocked() {
        return false;
    }

    // 비밀번호 사용기간 만료
    @Override
    public boolean isCredentialsNonExpired() {
        return false;
    }

    // 계정 활성화 상태
    @Override
    public boolean isEnabled() {
        return false;
    }

}
