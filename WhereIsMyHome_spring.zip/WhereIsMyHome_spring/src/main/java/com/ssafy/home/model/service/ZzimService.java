package com.ssafy.home.model.service;
import java.util.List;

import com.ssafy.home.model.dto.zzim.request.PostZzimRequestDto;
import com.ssafy.home.model.dto.zzim.response.GetZzimsResponseDto;

public interface ZzimService {
	public boolean postZzim(PostZzimRequestDto dto);
	public boolean deleteZzim(String lat, String lng, int userId);
	public List<GetZzimsResponseDto> getZzims(int userId); 
}
