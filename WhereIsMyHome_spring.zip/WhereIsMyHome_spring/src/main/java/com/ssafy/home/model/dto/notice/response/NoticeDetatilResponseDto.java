package com.ssafy.home.model.dto.notice.response;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NoticeDetatilResponseDto {
	private int noticeId;
	private int userId;
	private String title;
	private String content;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	
	private String id;
	private String email;
	private String profileImgeUrl;
	private String nickname;
}
