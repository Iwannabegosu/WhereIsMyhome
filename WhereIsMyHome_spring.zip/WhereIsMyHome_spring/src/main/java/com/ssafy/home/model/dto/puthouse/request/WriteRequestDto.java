	package com.ssafy.home.model.dto.puthouse.request;

import com.ssafy.home.model.entity.PutHouse;

import lombok.Data;

@Data
public class WriteRequestDto {
	private String title;
	private String content;
	private int userId;
	
	public PutHouse toEntity() {
		return PutHouse
				.builder()
				.putHouseId(0)
				.title(title)
				.content(content)
				.userId(userId)
				.build();
	}
}
