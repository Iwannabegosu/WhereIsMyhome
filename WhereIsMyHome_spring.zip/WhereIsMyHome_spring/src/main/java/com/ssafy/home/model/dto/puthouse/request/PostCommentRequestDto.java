package com.ssafy.home.model.dto.puthouse.request;

import com.ssafy.home.model.entity.PutHouseComment;

import lombok.Data;

@Data
public class PostCommentRequestDto {
	private int putHouseId;
	private int userId;
	private String content;
	
	public PutHouseComment toEntity() {
		return PutHouseComment
				.builder()
				.putHouseId(putHouseId)
				.userId(userId)
				.content(content)
				.build();
	}
}
