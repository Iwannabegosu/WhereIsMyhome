package com.ssafy.home.model.dto.user.request;

import lombok.Data;

@Data
public class FindPasswordRequestDto {
	private String id;
	private String email;
}
