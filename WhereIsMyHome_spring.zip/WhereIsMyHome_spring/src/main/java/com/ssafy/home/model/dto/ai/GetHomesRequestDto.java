package com.ssafy.home.model.dto.ai;

import lombok.Data;

@Data
public class GetHomesRequestDto {
	private String aptName;
	private String className;
	private String sidoName;
	private String dongName;
	private String gugunName;
	private int pyung;
	private double dealAmount;
	private double lat;
	private double lng;
	private double excluUseAr;
}
