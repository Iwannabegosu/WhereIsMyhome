package com.ssafy.home.model.service;

import com.ssafy.home.model.dto.user.request.FindPasswordRequestDto;
import com.ssafy.home.model.dto.user.request.SigninRequestDto;
import com.ssafy.home.model.dto.user.request.SignupRequestDto;

public interface UserService {
	public boolean idcheck(String id);
	public boolean nicknamecheck(String nickname);
	public boolean signup(SignupRequestDto signupRequestDto);
	public String signin(SigninRequestDto signinRequestDto);
	public String findid(String email);
	public String findpassword(FindPasswordRequestDto findPasswordRequestDto);
	
}
