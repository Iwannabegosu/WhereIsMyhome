package com.ssafy.home.model.dto.board.request;

import lombok.Data;

@Data
public class BookmarkRequestDto {
	private int userId;
}
