package com.ssafy.home.model.entity;

import com.ssafy.home.model.dto.zzim.response.GetZzimsResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Zzim {
	private int zzimTbId;
	private int userId;
	private String lat; //
	private String lng; //
	private String className; 
	private String excluUseAr; //
	private String dealAmount; //
	private String sidoName;
	private String gugunName;
	private String dongName;
	private String aptName;
	private String pyung; //
	
//	public GetZzimsResponseDto toGetZzimsResponseDto() {
//	    return GetZzimsResponseDto.builder()
//	            .zzimTbId(zzimTbId)
//	            .userId(userId)
//	            .lat(lat != null ? Double.parseDouble(lat) : 0.0) // 기본값 0.0
//	            .lng(lng != null ? Double.parseDouble(lng) : 0.0)
//	            .className(className != null ? className : "") // 빈 문자열 처리
//	            .excluUseAr(excluUseAr != null ? Double.parseDouble(excluUseAr) : 0.0)
//	            .dealAmount(dealAmount != null ? Double.parseDouble(dealAmount) : 0.0)
//	            .sidoName(sidoName != null ? sidoName : "")
//	            .gugunName(gugunName != null ? gugunName : "")
//	            .dongName(dongName != null ? dongName : "")
//	            .aptName(aptName != null ? aptName : "")
//	            .pyung(pyung != null ? Double.parseDouble(pyung) : 0.0)
//	            .build();
//	}
	
	public GetZzimsResponseDto toGetZzimsResponseDto() {
		return GetZzimsResponseDto
				.builder()
				.zzimTbId(zzimTbId)
				.userId(userId)
				.lat(Double.parseDouble(lat))
				.lng(Double.parseDouble(lng))
				.className(className)
				.excluUseAr(Double.parseDouble(excluUseAr))
				.dealAmount(Double.parseDouble(dealAmount))
				.sidoName(sidoName)
				.gugunName(gugunName)
				.dongName(dongName)
				.aptName(aptName)
				.pyung(Double.parseDouble(pyung))
				.build();
	}
}
