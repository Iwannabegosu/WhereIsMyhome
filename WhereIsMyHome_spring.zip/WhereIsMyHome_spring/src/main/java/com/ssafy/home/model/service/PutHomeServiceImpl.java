package com.ssafy.home.model.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.home.model.dto.puthouse.request.PutHouseBookmarkRequestDto;
import com.ssafy.home.model.dto.puthouse.request.DeleteCommentRequestDto;
import com.ssafy.home.model.dto.puthouse.request.DetailLikeListRequestDto;
import com.ssafy.home.model.dto.puthouse.request.LikeCancelRequestDto;
import com.ssafy.home.model.dto.puthouse.request.LikeRequestDto;
import com.ssafy.home.model.dto.puthouse.request.PostCommentRequestDto;
import com.ssafy.home.model.dto.puthouse.request.PutHouseBookmarkCancelRequestDto;
import com.ssafy.home.model.dto.puthouse.request.PutHouseBookmarkListRequestDto;
import com.ssafy.home.model.dto.puthouse.request.SearchPaginationRequestDto;
import com.ssafy.home.model.dto.puthouse.request.UpdateCommentRequestDto;
import com.ssafy.home.model.dto.puthouse.request.UpdateRequestDto;
import com.ssafy.home.model.dto.puthouse.request.ViewRequestDto;
import com.ssafy.home.model.dto.puthouse.request.WriteRequestDto;
import com.ssafy.home.model.dto.puthouse.response.DetailLikeListResponseDto;
import com.ssafy.home.model.dto.puthouse.response.DetailResponseDto;
import com.ssafy.home.model.dto.puthouse.response.ListAllResponseDto;
import com.ssafy.home.model.dto.puthouse.response.ListCommentResponseDto;
import com.ssafy.home.model.dto.puthouse.response.PutHouseBookmarkListResponseDto;
import com.ssafy.home.model.dto.puthouse.response.SearchListResponseDto;
import com.ssafy.home.model.entity.PutHouse;
import com.ssafy.home.model.entity.PutHouseBookmark;
import com.ssafy.home.model.entity.PutHouseComment;
import com.ssafy.home.model.entity.PutHouseLike;
import com.ssafy.home.model.mapper.PutHouseMapper;

@Service
public class PutHomeServiceImpl implements PutHomeService {
	
	@Autowired
	PutHouseMapper mapper;

	@Override
	public boolean write(WriteRequestDto writeRequestDto) {
		int cnt = mapper.write(writeRequestDto.toEntity());
		return cnt == 1;
	}

	@Override
	public List<ListAllResponseDto> listAll(int page, int option) {
		int count = 15; // 한 페이지에 몇개의 데이터를 보여주는가
		int offset = (page - 1) * count;
		List<PutHouse> listAll = mapper.listAll(offset, count, option);
		return listAll.stream().map(PutHouse::toListAllResponseDto).collect(Collectors.toList());
	}
	
	@Override
	public List<SearchListResponseDto> searchList(int page, String word) {
		int count = 15;
		int offset = (page - 1) * count;
		List<PutHouse> searchList = mapper.searchList(offset, count, word);
		return searchList.stream().map(PutHouse::toSearchListResponseDto).collect(Collectors.toList());
	}
	
	@Override
	public int pagination() {
		return mapper.pagination();
	}
	
	@Override
	public int searchPagination(SearchPaginationRequestDto searchPaginationRequestDto) {
		return mapper.searchPagination(searchPaginationRequestDto.getWord());
	}

	@Override
	public DetailResponseDto detail(int putHouseId) {
		PutHouse detail = mapper.detail(putHouseId);
		return detail.toDetailResponseDto();
	}

	@Override
	public boolean delete(int putHouseId) {
		int cnt = mapper.delete(putHouseId);
		return cnt == 1;
	}
	
	@Override
	public boolean update(int putHouseId, UpdateRequestDto updateRequestDto) {
		updateRequestDto.setPutHouseId(putHouseId);
		int cnt = mapper.update(updateRequestDto.toEntity());
		return cnt == 1;
	}

	@Override
	public boolean view(int putHouseId, ViewRequestDto viewRequestDto) {
		int cnt = mapper.view(putHouseId, viewRequestDto.getUserId());
		return cnt == 1;
	}

	@Override
	public boolean like(int putHouseId, LikeRequestDto likeRequestDto) {
		int cnt = mapper.like(putHouseId, likeRequestDto.getUserId());
		return cnt == 1;
	}
	
	@Override
	public List<DetailLikeListResponseDto> detailLikeList(DetailLikeListRequestDto detailLikeListRequestDto) {
		List<PutHouseLike> detailLikeList = mapper.detailLikeList(detailLikeListRequestDto.getPutHouseId());
		return detailLikeList.stream().map(PutHouseLike::toDetailLikeListResponseDto).collect(Collectors.toList());
	}

	@Override
	public boolean likeCancel(int putHouseId, LikeCancelRequestDto likeCancelRequestDto) {
		int cnt = mapper.likeCancel(putHouseId, likeCancelRequestDto.getUserId());
		return cnt == 1;
	}

	@Override
	public boolean postComment(int putHouseId, PostCommentRequestDto postCommentRequestDto) {
		postCommentRequestDto.setPutHouseId(putHouseId);
		int cnt = mapper.postComment(postCommentRequestDto.toEntity());
		return cnt == 1;
	}

	@Override
	public List<ListCommentResponseDto> listComment(int putHouseId) {
		List<PutHouseComment> listComment = mapper.listComment(putHouseId);
		return listComment.stream().map(PutHouseComment::toListCommentResponseDto).collect(Collectors.toList());
	}

	@Override
	public boolean deleteComment(int putHouseId, DeleteCommentRequestDto deleteCommentRequestDto) {
		int cnt = mapper.deleteComment(deleteCommentRequestDto.getPutHouseCommentId());
		return cnt == 1;
	}

	@Override
	public boolean updateComment(int putHouseId, UpdateCommentRequestDto updateCommentRequestDto) {
		int cnt = mapper.updateComment(updateCommentRequestDto.toEntity());
		return cnt == 1;
	}

	@Override
	public boolean bookmark(int putHouseId, PutHouseBookmarkRequestDto putBookmarkRequestDto) {
		int cnt = mapper.bookmark(putHouseId, putBookmarkRequestDto.getUserId());
		return cnt == 1;
	}
	
	@Override
	public List<PutHouseBookmarkListResponseDto> bookmarkList(int putHouseId) {
		List<PutHouseBookmark> bookmarkList = mapper.bookmarkList(putHouseId);
		return bookmarkList.stream().map(PutHouseBookmark::toPutHouseBookmarkListResponseDto).collect(Collectors.toList());
	}

	@Override
	public boolean bookmarkCancel(int putHouseId, PutHouseBookmarkCancelRequestDto putHouseBookmarkCancelRequestDto) {
		int cnt = mapper.bookmarkCancel(putHouseId, putHouseBookmarkCancelRequestDto.getUserId());
		return cnt == 1;
	}
}
