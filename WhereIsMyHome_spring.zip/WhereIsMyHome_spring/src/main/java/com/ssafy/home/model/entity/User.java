package com.ssafy.home.model.entity;

import java.util.Collections;
import java.util.List;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.ssafy.home.model.dto.my.response.ShowInfoResponseDto;
import com.ssafy.home.security.PrincipalUser;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class User {
    private int userId;
    private String id;
    private String password;
    private String email;
    private String nickname;
    private String profileImgUrl;
    
    private RoleRegister roleRegister; // 단일 RoleRegister 객체로 변경
    
    public List<SimpleGrantedAuthority> getAuthorities() {
        return Collections.singletonList(new SimpleGrantedAuthority(roleRegister.getRole().getRoleName()));
    }
    
    public PrincipalUser toPrincipalUser() {
    	return PrincipalUser
    			.builder()
    			.userId(userId)
    			.id(id)
    			.email(email)
    			.authorities(getAuthorities())
    			.build();
    }
    
    public ShowInfoResponseDto toShowInfoResponseDto() {
    	return ShowInfoResponseDto
    			.builder()
    			.userId(userId)
    			.id(id)
    			.email(email)
    			.nickname(nickname)
    			.profileImgUrl(profileImgUrl)
    			.build();
    }
    
}
