package com.ssafy.home.model.dto.board.request;

import com.ssafy.home.model.entity.Board;

import lombok.Data;

@Data
public class BoardPostRequestDto {
	private int userId;
	private String title;
	private String content;
	
	public Board toEntity() {
		return Board
				.builder()
				.userId(userId)
				.title(title)
				.content(content)
				.build();
	}
}
