package com.ssafy.home.model.dto.notice.request;

import com.ssafy.home.model.entity.Notice;

import lombok.Data;

@Data
public class NoticeWriteRequestDto {
	private int userId;
	private String title;
	private String content;
	
	public Notice toNoticeEntity() {
		return Notice
				.builder()
				.userId(userId)
				.title(title)
				.content(content)
				.build();
	}
}
