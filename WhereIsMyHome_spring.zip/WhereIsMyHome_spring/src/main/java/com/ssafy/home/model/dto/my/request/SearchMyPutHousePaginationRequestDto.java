package com.ssafy.home.model.dto.my.request;

import lombok.Data;

@Data
public class SearchMyPutHousePaginationRequestDto {
	private int userId;
	private String word;
}
