package com.ssafy.home.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ssafy.home.model.entity.PutHouse;
import com.ssafy.home.model.entity.User;

@Mapper
public interface MyMapper {
	public User showInfo(int userId);
	public User nicknamecheck(String nickname);
	public int updateInfo(User user);
	public int updateInfoWithoutPassword(User user);
	public User findUserByUserId(int userId);
	
	public List<PutHouse> showMyPutHouses(@Param("offset") int offset, @Param("count") int count, @Param("userId") int userId);
	public int myPutHousePagination(int userId);
	public List<PutHouse> searchMyPutHouses(@Param("offset") int offset, @Param("count") int count, @Param("word") String word, @Param("userId") int userId);
	public int searchMyPutHousePagination(@Param("word") String word, @Param("userId") int userId);
	public int deleteMyPutHouse(int putHouseId);
}
