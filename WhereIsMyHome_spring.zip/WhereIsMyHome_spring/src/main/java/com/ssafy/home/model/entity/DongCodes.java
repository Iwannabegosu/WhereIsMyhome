package com.ssafy.home.model.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DongCodes {
	private String dongCode;
	private String sidoName;
	private String gugunName;
	private String dongName;
}
