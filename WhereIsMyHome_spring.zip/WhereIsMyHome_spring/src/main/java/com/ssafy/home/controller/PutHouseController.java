package com.ssafy.home.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.home.model.dto.puthouse.request.PutHouseBookmarkRequestDto;
import com.ssafy.home.model.dto.puthouse.request.DeleteCommentRequestDto;
import com.ssafy.home.model.dto.puthouse.request.DetailLikeListRequestDto;
import com.ssafy.home.model.dto.puthouse.request.LikeCancelRequestDto;
import com.ssafy.home.model.dto.puthouse.request.LikeRequestDto;
import com.ssafy.home.model.dto.puthouse.request.PostCommentRequestDto;
import com.ssafy.home.model.dto.puthouse.request.PutHouseBookmarkCancelRequestDto;
import com.ssafy.home.model.dto.puthouse.request.PutHouseBookmarkListRequestDto;
import com.ssafy.home.model.dto.puthouse.request.SearchPaginationRequestDto;
import com.ssafy.home.model.dto.puthouse.request.UpdateCommentRequestDto;
import com.ssafy.home.model.dto.puthouse.request.UpdateRequestDto;
import com.ssafy.home.model.dto.puthouse.request.ViewRequestDto;
import com.ssafy.home.model.dto.puthouse.request.WriteRequestDto;
import com.ssafy.home.model.service.PutHomeService;

@RestController
@RequestMapping("/puthouse")
public class PutHouseController {
	
	@Autowired
	PutHomeService service;
	
	// 방내놓기 게시물 등록
	@PostMapping("/posts")
	public ResponseEntity<?> write(@RequestBody WriteRequestDto writeRequestDto) {
		return ResponseEntity.ok(service.write(writeRequestDto));
	}
	
	// 방내놓기 게시물 전체 조회(다건 조회 - option = 0 : 최신순, option = 1 : 트렌딩)
	@GetMapping("")
	public ResponseEntity<?> listAll(@RequestParam int page, @RequestParam int option) {
		return ResponseEntity.ok(service.listAll(page, option));
	}
	
	// 방내놓기 게시물 검색 조회(다건 조회)
	@GetMapping("/search")
	public ResponseEntity<?> searchList(@RequestParam int page, @RequestParam String word) {
		return ResponseEntity.ok(service.searchList(page, word));
	}
	
	// 방내놓기 게시물 페이지네이션(총 검색된 게시물 개수)
	@GetMapping("/search/pagination")
	public ResponseEntity<?> searchPagination(@RequestBody SearchPaginationRequestDto searchPaginationRequestDto) {
		return ResponseEntity.ok(service.searchPagination(searchPaginationRequestDto));
	}
	
	// 페이지네이션(총 게시물 개수 totalCount)
	@GetMapping("/pagination")
	public ResponseEntity<?> pagination() {
		return ResponseEntity.ok(service.pagination());
	}
	
	// 방내놓기 게시물 상세 조회(단건 조회)
	@GetMapping("/{puthouseid}") 
	public ResponseEntity<?> detail(@PathVariable("puthouseid") int putHouseId) {
		return ResponseEntity.ok(service.detail(putHouseId));
	}
	
	// 방내놓기 게시물 삭제(단건 삭제)
	@DeleteMapping("/{puthouseid}")
	public ResponseEntity<?> delete(@PathVariable("puthouseid") int putHouseId){
		return ResponseEntity.ok(service.delete(putHouseId));
	}
	
	// 방내놓기 게시물 수정(단건 수정)
	@PutMapping("/{puthouseid}/update")
	public ResponseEntity<?> update(@PathVariable("puthouseid") int putHouseId, @RequestBody UpdateRequestDto updateRequestDto) {
		return ResponseEntity.ok(service.update(putHouseId, updateRequestDto));
	}
	
	// 방내놓기 게시물 조회수 증가
	@PostMapping("/{puthouseid}")
	public ResponseEntity<?> view(@PathVariable("puthouseid") int putHouseId, @RequestBody ViewRequestDto viewRequestDto) {
		return ResponseEntity.ok(service.view(putHouseId, viewRequestDto));
	}
	
	// 방내놓기 게시물 좋아요
	@PostMapping("/{puthouseid}/like")
	public ResponseEntity<?> like(@PathVariable("puthouseid") int putHouseId, @RequestBody LikeRequestDto likeRequestDto) {
		return ResponseEntity.ok(service.like(putHouseId, likeRequestDto));
	}
	
	// 방내놓기 게시물 상세 좋아요한 사용자 정보 리스트 조회
	@GetMapping("/likeusers")
	public ResponseEntity<?> detailLikeList(@RequestBody DetailLikeListRequestDto detailLikeListRequestDto) {
		return ResponseEntity.ok(service.detailLikeList(detailLikeListRequestDto));
	}
	
	// 방내놓기 게시물 좋아요 취소
	@DeleteMapping("/{puthouseid}/like")
	public ResponseEntity<?> likeCancel(@PathVariable("puthouseid") int putHouseId, @RequestBody LikeCancelRequestDto likeCancelRequestDto) {
		return ResponseEntity.ok(service.likeCancel(putHouseId, likeCancelRequestDto));
	}
	
	// 방내놓기 게시물 댓글 작성
	@PostMapping("/{puthouseid}/comment")
	public ResponseEntity<?> postComment(@PathVariable("puthouseid") int putHouseId, @RequestBody PostCommentRequestDto postCommentRequestDto) {
		return ResponseEntity.ok(service.postComment(putHouseId, postCommentRequestDto));
	}
	
	// 방내놓기 게시물 댓글 리스트 조회(다건)
	@GetMapping("/{puthouseid}/comment")
	public ResponseEntity<?> listComment(@PathVariable("puthouseid") int putHouseId) {
		return ResponseEntity.ok(service.listComment(putHouseId));
	}
	
	// 방내놓기 게시물 댓글 삭제(단건)
	@DeleteMapping("/{puthouseid}/comment")
	public ResponseEntity<?> deleteComment(@PathVariable("puthouseid") int putHouseId, @RequestBody DeleteCommentRequestDto deleteCommentRequestDto) {
		return ResponseEntity.ok(service.deleteComment(putHouseId, deleteCommentRequestDto));
	}
	
	// 방내놓기 게시물 댓글 수정(단건)
	@PutMapping("/{puthouseid}/comment")
	public ResponseEntity<?> updateComment(@PathVariable("puthouseid") int putHouseId, @RequestBody UpdateCommentRequestDto updateCommentRequestDto) {
		return ResponseEntity.ok(service.updateComment(putHouseId, updateCommentRequestDto));
	}
	
	// 방내놓기 게시물 상세 북마크 등록
	@PostMapping("/{puthouseid}/bookmark")
	public ResponseEntity<?> bookmark(@PathVariable("puthouseid") int putHouseId, @RequestBody PutHouseBookmarkRequestDto putBookmarkRequestDto) {
		return ResponseEntity.ok(service.bookmark(putHouseId, putBookmarkRequestDto));
	}
	
	// 방네놓기 게시물 상세 북마크 적용중인 회원 리스트 조회
	@GetMapping("/{puthouseid}/bookmark")
	public ResponseEntity<?> bookmarkList(@PathVariable("puthouseid") int putHouseId) {
		return ResponseEntity.ok(service.bookmarkList(putHouseId));
	}
	
	// 방네놓기 게시물 상세 북마크 삭제
	@DeleteMapping("/{puthouseid}/bookmark")
	public ResponseEntity<?> bookmarkCancel(@PathVariable("puthouseid") int putHouseId, @RequestBody PutHouseBookmarkCancelRequestDto putHouseBookmarkCancelRequestDto) {
		System.out.println(putHouseBookmarkCancelRequestDto);
		return ResponseEntity.ok(service.bookmarkCancel(putHouseId, putHouseBookmarkCancelRequestDto));
	}
}
