package com.ssafy.home.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.home.model.dto.zzim.request.PostZzimRequestDto;
import com.ssafy.home.model.service.ZzimService;

@RestController
@RequestMapping("/zzim")
public class ZzimController {
	
	@Autowired
	ZzimService service;
	
	@PostMapping("")
	public ResponseEntity<?> postZzim(@RequestBody PostZzimRequestDto dto) {
		System.out.println(dto);
		return ResponseEntity.ok(service.postZzim(dto));
	}
	
	@DeleteMapping("/{lat}/{lng}/{userId}")
	public ResponseEntity<?> deleteZzim(@PathVariable String lat, @PathVariable String lng, @PathVariable int userId) {
		return ResponseEntity.ok(service.deleteZzim(lat, lng, userId));
	}
	
	@GetMapping("/{userId}")
	public ResponseEntity<?> getZzims(@PathVariable int userId) {
		return ResponseEntity.ok(service.getZzims(userId));
	}
}
