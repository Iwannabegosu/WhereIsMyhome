package com.ssafy.home.model.service;

import java.util.List;

import com.ssafy.home.model.dto.notice.request.NoticeUpdateDto;
import com.ssafy.home.model.dto.notice.request.NoticeWriteRequestDto;
import com.ssafy.home.model.dto.notice.response.NoticeDetatilResponseDto;
import com.ssafy.home.model.dto.notice.response.NoticeListAllResponseDto;

public interface NoticeService {
	public boolean post(NoticeWriteRequestDto dto);
	public boolean delNotice(int noticeId);
	public List<NoticeListAllResponseDto> getListAll(int page);
	public int getNoticeCount();
	public List<NoticeListAllResponseDto> getSearchList(int page, String word);
	public int getSearchCount(String word);
	public NoticeDetatilResponseDto getNotice(int noticeId);
	public boolean updateNotice(int noticeId, NoticeUpdateDto dto);
	public List<NoticeListAllResponseDto> descNotice();
}
