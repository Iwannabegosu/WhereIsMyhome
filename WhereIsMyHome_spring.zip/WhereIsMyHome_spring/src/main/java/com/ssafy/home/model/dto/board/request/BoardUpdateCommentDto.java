package com.ssafy.home.model.dto.board.request;

import com.ssafy.home.model.entity.Comment;

import lombok.Data;

@Data
public class BoardUpdateCommentDto {
	private int commentId;
	private String content;
	
	public Comment toEntity() {
		return Comment
				.builder()
				.commentId(commentId)
				.content(content)
				.build();
	}
	
}
