package com.ssafy.home.model.dto.map.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LocationResponseDto {
	private String aptSeq; //primary key
	private double lat;
	private double lng;
	private String className; // db 구별용
	private double excluUseAr; // 제곱미터
	private double dealAmount; // 매매가
	private int pyung; // 평수
	private String sidoName;
	private String gugunName;
	private String dongName;
	private String aptName;
}
