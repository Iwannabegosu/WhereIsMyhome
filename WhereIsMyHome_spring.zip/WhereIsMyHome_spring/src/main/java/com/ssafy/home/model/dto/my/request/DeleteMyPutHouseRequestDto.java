package com.ssafy.home.model.dto.my.request;

import lombok.Data;

@Data
public class DeleteMyPutHouseRequestDto {
	private int putHouseId;
}
