package com.ssafy.home.model.dto.puthouse.request;

import com.ssafy.home.model.entity.PutHouse;

import lombok.Data;

@Data
public class UpdateRequestDto {
	private int putHouseId;
	private String title;
	private String content;
	
	public PutHouse toEntity() {
		return PutHouse
				.builder()
				.putHouseId(putHouseId)
				.title(title)
				.content(content)
				.build();
	}
}
