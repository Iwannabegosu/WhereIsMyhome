package com.ssafy.home.model.entity;

import com.ssafy.home.model.dto.map.response.DongResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Dong {
	private int dongId;
	private String average;
	private String dongName;
	private String lat;
	private String lng;
	private String className;
	
	public DongResponseDto toDongDto() {
		double number = Double.parseDouble(average);
		double result = number/10000;
		result = Math.round(result * 10.0) / 10.0;
		return DongResponseDto
				.builder()
				.dongId(dongId)
				.average(result)
				.dongName(dongName)
				.lat(Double.parseDouble(lat))
				.lng(Double.parseDouble(lng))
				.className(className)
				.build();		
	}
}
