package com.ssafy.home.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.home.model.dto.my.request.DeleteMyPutHouseRequestDto;
import com.ssafy.home.model.dto.my.request.MyPutHousePaginationRequestDto;
import com.ssafy.home.model.dto.my.request.NicknameCheckRequestDto;
import com.ssafy.home.model.dto.my.request.PasswordCheckRequestDto;
import com.ssafy.home.model.dto.my.request.SearchMyPutHousePaginationRequestDto;
import com.ssafy.home.model.dto.my.request.SearchMyPutHousesRequestDto;
import com.ssafy.home.model.dto.my.request.ShowInfoRequestDto;
import com.ssafy.home.model.dto.my.request.ShowMyPutHouseRequestDto;
import com.ssafy.home.model.dto.my.request.UpdateInfoRequestDto;
import com.ssafy.home.model.service.MyService;

@RestController
@RequestMapping("/my")
public class MyController {
	
	@Autowired
	MyService service;
	
	// 마이페이지 수정
	@GetMapping("/{userId}")
	public ResponseEntity<?> showInfo(@PathVariable int userId) {
		return ResponseEntity.ok(service.showInfo(userId));
	}
	
	@GetMapping("/nicknamecheck/{nickname}")
	public ResponseEntity<?> nicknamecheck(@PathVariable String nickname) {
		return ResponseEntity.ok(service.nicknamecheck(nickname));
	}
	
	@PutMapping("/")
	public ResponseEntity<?> updateInfo(@RequestBody UpdateInfoRequestDto updateRequestDto) {
		System.out.println(updateRequestDto);
		return ResponseEntity.ok(service.updateInfo(updateRequestDto));
	}
	
	@GetMapping("/passwordcheck")
	public ResponseEntity<?> passwordcheck(@RequestBody PasswordCheckRequestDto passwordCheckRequestDto) {
		return ResponseEntity.ok(service.passwordcheck(passwordCheckRequestDto));
	}
	
	// 내가 작성한 방내놓기 게시물
	@GetMapping("/puthouse")
	public ResponseEntity<?> showMyPutHouses(@RequestBody ShowMyPutHouseRequestDto showMyPutHouseRequestDto, @RequestParam int page) {
		return ResponseEntity.ok(service.showMyPutHouses(showMyPutHouseRequestDto, page));
	}
	
	@GetMapping("/puthouse/pagination")
	public ResponseEntity<?> myPutHousePagination(@RequestBody MyPutHousePaginationRequestDto myPutHousePaginationRequestDto) {
		return ResponseEntity.ok(service.myPutHousePagination(myPutHousePaginationRequestDto));
	}
	
	@GetMapping("/puthouse/search")
	public ResponseEntity<?> searchMyPutHouses(@RequestParam int page, @RequestParam String word, @RequestBody SearchMyPutHousesRequestDto SearchMyPutHousesRequestDto) {
		return ResponseEntity.ok(service.searchMyPutHouses(page, word, SearchMyPutHousesRequestDto));
	}
	
	@GetMapping("/puthouse/search/pagination")
	public ResponseEntity<?> searchMyPutHousePagination(@RequestBody SearchMyPutHousePaginationRequestDto searchMyPutHousePaginationRequestDto) {
		return ResponseEntity.ok(service.searchMyPutHousePagination(searchMyPutHousePaginationRequestDto));
	}
	
	@DeleteMapping("/puthouse")
	public ResponseEntity<?> deleteMyPutHouse(@RequestBody DeleteMyPutHouseRequestDto deleteMyPutHouseRequestDto) {
		return ResponseEntity.ok(service.deleteMyPutHouse(deleteMyPutHouseRequestDto));
	}
	
}
