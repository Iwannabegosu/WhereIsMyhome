package com.ssafy.home.model.entity;

import com.ssafy.home.model.dto.map.response.DoResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Boundary {
	private int boundarySiId;
	private String midLat;
	private String midLong;
	private String sggCd;
	private String name;
	private String className;
	
	public DoResponseDto toDoResponseDto() {
		return DoResponseDto
				.builder()
				.lat(Double.parseDouble(midLat))
				.lng(Double.parseDouble(midLong))
				.sggCd(Integer.parseInt(sggCd))
				.name(name)
				.className(className)
				.build();
	}
}
