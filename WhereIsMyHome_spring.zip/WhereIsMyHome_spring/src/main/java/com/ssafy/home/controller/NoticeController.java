package com.ssafy.home.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.home.model.dto.notice.request.NoticeUpdateDto;
import com.ssafy.home.model.dto.notice.request.NoticeWriteRequestDto;
import com.ssafy.home.model.service.NoticeService;

@RestController
@RequestMapping("notice")
public class NoticeController {
	@Autowired
	NoticeService noticeService;
	// C
	// 공지사항 작성
	@PostMapping("/post")
	public ResponseEntity<?> post(@RequestBody NoticeWriteRequestDto dto){
		return ResponseEntity.ok(noticeService.post(dto));
	}
	// D
	// 공지사항 삭제
	@DeleteMapping("/{noticeId}")
	public ResponseEntity<?> deleteNotice(@PathVariable("noticeId")int noticeId){
		return ResponseEntity.ok(noticeService.delNotice(noticeId));
	}
	
	// R
	// 공지사항 조회(다건)
	@GetMapping("")
	public ResponseEntity<?> getListAll(@RequestParam("page") int page){
		return ResponseEntity.ok(noticeService.getListAll(page));
	}
	
	// 공지사항 개수 출력
	@GetMapping("/pagination")
	public ResponseEntity<?> getNoticeCount(){
		return ResponseEntity.ok(noticeService.getNoticeCount());
	}
	
	// 공지사항 검색
	@GetMapping("/search")
	public ResponseEntity<?> getSearchList(@RequestParam("word") String word,
										   @RequestParam("page") int page){
		return ResponseEntity.ok(noticeService.getSearchList(page ,word));
	}
	
	// 공지사항 검색된거 개수 출력
	@GetMapping("/search/pagination")
	public ResponseEntity<?> getSearchCount(@RequestParam("word") String word){
		return ResponseEntity.ok(noticeService.getSearchCount(word));
	}
	
	// 공지사항 조회(단건)
	@GetMapping("/{noticeId}")
	public ResponseEntity<?> getNotice(@PathVariable("noticeId") int noticeId){
		
		System.out.println(noticeService.getNotice(noticeId));
		return ResponseEntity.ok(noticeService.getNotice(noticeId));
	}
	
	// U
	// 공지사항 업데이트
	@PutMapping("/{noticeId}/update")
	public ResponseEntity<?> updateNotice(@PathVariable("noticeId") int noticeId,
				                          @RequestBody NoticeUpdateDto dto){
		return ResponseEntity.ok(noticeService.updateNotice(noticeId, dto));
	}
	
	@GetMapping("/desc")
	public ResponseEntity<?> descNotice() {
		return ResponseEntity.ok(noticeService.descNotice());
	}
}
