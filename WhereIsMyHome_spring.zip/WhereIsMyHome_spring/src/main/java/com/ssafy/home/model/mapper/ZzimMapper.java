package com.ssafy.home.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ssafy.home.model.entity.Zzim;

@Mapper
public interface ZzimMapper {
	public int postZzim(Zzim zzim);
	public int deleteZzim(@Param("lat") String lat,@Param("lng") String lng, @Param("userId") int userId);
	public List<Zzim> getZzims(int userId);
}
