package com.ssafy.home.model.dto.zzim.request;

import com.ssafy.home.model.entity.Zzim;

import lombok.Data;

@Data
public class PostZzimRequestDto {
		private int userId;
		private String lat;
		private String lng;
		private String className;
		private String excluUseAr;
		private String dealAmount;
		private String sidoName;
		private String gugunName;
		private String dongName;
		private String aptName;
		private String pyung;
		
		
		public Zzim toEntity() {
			return Zzim
					.builder()
					.zzimTbId(0)
					.userId(userId)
					.lat(lat)
					.lng(lng)
					.className(className)
					.excluUseAr(excluUseAr)
					.dealAmount(dealAmount)
					.sidoName(sidoName)
					.gugunName(gugunName)
					.dongName(dongName)
					.aptName(aptName)
					.pyung(pyung)
					.build();
		}
}
