package com.ssafy.home.model.entity;

import com.ssafy.home.model.dto.board.response.CheckBoomarksResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BoardBookmark {
	private int boardBookmarkId;
	private int boardId;
	private int userId;
	
	public CheckBoomarksResponseDto toCheckBoomarksResponseDto() {
		return CheckBoomarksResponseDto
				.builder()
				.userId(userId)
				.build();
	}
}
