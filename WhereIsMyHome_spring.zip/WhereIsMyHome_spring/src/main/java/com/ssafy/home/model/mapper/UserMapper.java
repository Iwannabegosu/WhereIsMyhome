package com.ssafy.home.model.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ssafy.home.model.entity.User;

@Mapper
public interface UserMapper {
	public User nicknamecheck(String nickname);
	public User idcheck(String id);
	public int signup(User user);
	public User findUserById(String id);
	public int saveRole(int userId);
	public String findid(String email);
	public User findpassword(@Param("id") String id, @Param("email") String email);
	public int saveTempPassword(User user);
}
