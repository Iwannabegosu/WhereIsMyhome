package com.ssafy.home.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.home.model.dto.user.request.FindPasswordRequestDto;
import com.ssafy.home.model.dto.user.request.SigninRequestDto;
import com.ssafy.home.model.dto.user.request.SignupRequestDto;
import com.ssafy.home.model.service.UserService;
import com.ssafy.home.security.PrincipalUser;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	UserService service;
	
	@GetMapping("/idcheck")
	public ResponseEntity<?> idcheck(@RequestParam("id") String id) {
		return ResponseEntity.ok(service.idcheck(id));
	}
	
	@GetMapping("/nicknamecheck")
	public ResponseEntity<?> nicknamecheck(@RequestParam("nickname") String nickname) {
		return ResponseEntity.ok(service.nicknamecheck(nickname));
	}

	@PostMapping("/signup")
	public ResponseEntity<?> signup(@RequestBody SignupRequestDto signupRequestDto) {
		return ResponseEntity.ok(service.signup(signupRequestDto));
	}
	
	@PostMapping("/signin")
	public ResponseEntity<?> signin(@RequestBody SigninRequestDto signinRequestDto) {
		String token = service.signin(signinRequestDto);
		if(token == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("사용자 정보를 확인하세요.");
		}
		return ResponseEntity.ok(token);
	}
	
	@GetMapping("/findid")
	public ResponseEntity<?> findid(@RequestParam("email") String email) {
		return ResponseEntity.ok(service.findid(email));
	}
	
	@PostMapping("/findpassword")
	public ResponseEntity<?> findpassword(@RequestBody FindPasswordRequestDto findPasswordRequestDto) {
		return ResponseEntity.ok(service.findpassword(findPasswordRequestDto));
	}
	
//	@GetMapping("/principal")
//	public ResponseEntity<?> getPrincipal() {
//		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//		PrincipalUser principalUser = (PrincipalUser) authentication.getPrincipal();
//		return ResponseEntity.ok(principalUser);
//	}
}
