package com.ssafy.home.model.entity;

import com.ssafy.home.model.dto.board.response.BoardGetLikeListDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Like {
	private int likeId;
	private int boardId;
	private int userId;
	
	public BoardGetLikeListDto toLikeDto() {
		return BoardGetLikeListDto
				.builder()
				.boardId(boardId)
				.likeId(likeId)
				.userId(userId)
				.build();
	}
}
