package com.ssafy.home.model.dto.map.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DoResponseDto {
	private double lat; // 중앙 latitude
	private double lng; // 중앙 longitude
	private int sggCd; // 도 코드
	private String name; // 도시 이름
	private String className;
}
