package com.ssafy.home.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ssafy.home.model.entity.Board;
import com.ssafy.home.model.entity.BoardBookmark;
import com.ssafy.home.model.entity.Comment;
import com.ssafy.home.model.entity.Like;
@Mapper
public interface BoardMapper {
	public int posts(Board dto);
	public List<Board> getList();
	public Board getBoard(int boardId);
	public int like(@Param("boardId") int boarId,@Param("userId") int userId);
	public int delLike(@Param("boardId") int boardId, @Param("userId") int userId);
	public int delBoard(int boardId);
	public int view(@Param("boardId") int boarId,@Param("userId") int userId);
	public int comment(Comment entity);
	public int delComment(int commentId);
	public List<Comment> getComment(int boardId);
	public int updateBoard(Board entity);
	public int updateComment(Comment entity);
	public List<Board> getListAll(@Param("count") int count,
			                      @Param("option") int option, 
			                      @Param("offset") int offset);
	public int getPageCount();
	public List<Board> getSearchList(@Param("count") int count,
									 @Param("word") String word
									,@Param("offset") int offset);
	public int getSearchPageCount(String word);
	public int bookmark(@Param("boardId") int boardId, @Param("userId") int userId);
	public List<BoardBookmark> checkBoomarks(int boardId);
	public int cancelBookmark(@Param("boardId") int boardId, @Param("userId") int userId);
	public List<Like> getLike(int board);
}
