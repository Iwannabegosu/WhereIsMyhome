package com.ssafy.home.model.service;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.ssafy.home.jwt.JwtProvider;
import com.ssafy.home.model.dto.user.request.FindPasswordRequestDto;
import com.ssafy.home.model.dto.user.request.SigninRequestDto;
import com.ssafy.home.model.dto.user.request.SignupRequestDto;
import com.ssafy.home.model.entity.User;
import com.ssafy.home.model.mapper.UserMapper;

import ch.qos.logback.core.recovery.ResilientSyslogOutputStream;
import jakarta.mail.internet.MimeMessage;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserMapper mapper;
	
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
	@Autowired
	JwtProvider jwtProvider;
	
	@Autowired
	JavaMailSender javaMailSender;
	
	@Value("${spring.mail.address}")
	private String fromMailAddress;
	
    @Value("${server.port}")
    private String serverPort;
	
	private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+";
	
	@Override
	public boolean idcheck(String id) {
		User user = mapper.idcheck(id);
		if(user == null) return false;
		return true;
	}
	
	
	@Override
	public boolean nicknamecheck(String nickname) {
		User user = mapper.nicknamecheck(nickname);
		if(user == null) return false;
		return true;
	}
	

	@Override
	public boolean signup(SignupRequestDto signupRequestDto) {
		int cnt1 = mapper.signup(signupRequestDto.toEntity(passwordEncoder));
		int userId = mapper.findUserById(signupRequestDto.getId()).getUserId();
		int cnt2 = mapper.saveRole(userId);
		return cnt1 == 1 && cnt2 == 1;
	}

	@Override
	public String signin(SigninRequestDto signinRequestDto) {
		User user = mapper.findUserById(signinRequestDto.getId());
		System.out.println(user);
		if(user == null) {
			return null;
		}
		if(!passwordEncoder.matches(signinRequestDto.getPassword(), user.getPassword())) {
			return null;
		}
		return jwtProvider.generateToken(user);
	}

	@Override
	public String findid(String email) {
		return mapper.findid(email);
	}

	@Override
	public String findpassword(FindPasswordRequestDto findPasswordRequestDto) {
		String id = findPasswordRequestDto.getId();
		String email = findPasswordRequestDto.getEmail();
		User user = mapper.findpassword(id, email);
		if(user == null) {
			return "존재하는 사용자가 아닙니다";
		}
		
		String tempPassword = RandomStringUtils.random(10, CHARACTERS);
		user.setPassword(passwordEncoder.encode(tempPassword));
		int cnt = mapper.saveTempPassword(user);
		
		boolean mailCheck = false;
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		
		try {
			MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, false, "UTF-8"); // 파일 전송 시에는 true
			messageHelper.setSubject("임시 비밀번호 발급");
			messageHelper.setFrom(fromMailAddress);
			messageHelper.setTo(email);
			
			StringBuilder mailContent = new StringBuilder();
			mailContent.append("<div>");
			mailContent.append("<h1>임시 비밀번호 발급 확인(SSAFY 부동산)</h1>");
			mailContent.append("<hr />");
			mailContent.append("<div style='display: flex;'>");
			mailContent.append("<h2>임시 비밀번호 :&nbsp;</h2>");
			mailContent.append("<h2 style='color: #3ebded; text-decoration: underline;'>"+ tempPassword + "</h2>");
			mailContent.append("<a href='https://www.leagueoflegends.com/ko-kr/' style='");
			mailContent.append("border-radius: 8px;");
			mailContent.append("width: 150px;");
			mailContent.append("color: white;");
			mailContent.append("text-decoration: none;");
			mailContent.append("font-weight: 600;");
			mailContent.append("font-size: 18px;");
			mailContent.append("background-color: #3ebded;");
			mailContent.append("padding: 0 10px;");
			mailContent.append("margin-left: 30px;");
			mailContent.append("display: flex;");
			mailContent.append("justify-content: center;");
			mailContent.append("align-items: center;");
			mailContent.append("'>로그인 하러 가기</a>");
			mailContent.append("</div>");
			mailContent.append("<h3>해당 계정을 로그인하기 위한 임시 비밀번호 입니다. 로그인 후 비밀번호 변경해주세요.</h3>");
			mailContent.append("</div>");

            
            mimeMessage.setText(mailContent.toString(), "UTF-8", "html");
            
            javaMailSender.send(mimeMessage); // 메일 전송(최종)
            mailCheck = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(cnt == 1 && mailCheck) return "임시 비밀번로를 해당 이메일로 발송했습니다.";
		
		return "오류가 발생하였습니다. 다시 실행해 주세요.";
	}



	



	

}
