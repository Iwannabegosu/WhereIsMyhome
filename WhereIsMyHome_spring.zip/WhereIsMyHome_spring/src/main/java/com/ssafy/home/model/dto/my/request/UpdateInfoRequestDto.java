package com.ssafy.home.model.dto.my.request;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.ssafy.home.model.entity.User;

import lombok.Data;

@Data
public class UpdateInfoRequestDto {
	private int userId;
	private String password;
	private String nickname;
	private String profileImgUrl;
	
	public User toEntity(BCryptPasswordEncoder passwordEncoder) {
		return User
				.builder()
				.userId(userId)
				.password(passwordEncoder.encode(password))
				.nickname(nickname)
				.profileImgUrl(profileImgUrl)
				.build();
	}
	
	public User toEntity() {
		return User
				.builder()
				.userId(userId)
				.nickname(nickname)
				.profileImgUrl(profileImgUrl)
				.build();
	}
}
