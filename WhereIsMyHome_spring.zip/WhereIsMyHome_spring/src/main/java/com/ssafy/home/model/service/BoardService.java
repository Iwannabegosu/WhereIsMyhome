package com.ssafy.home.model.service;
import java.util.List;

import com.ssafy.home.model.dto.board.request.BoardCommentRequestDto;
import com.ssafy.home.model.dto.board.request.BoardDeleteCommentRequestDto;
import com.ssafy.home.model.dto.board.request.BoardLikeRequestDto;
import com.ssafy.home.model.dto.board.request.BoardPostRequestDto;
import com.ssafy.home.model.dto.board.request.BoardUpdateCommentDto;
import com.ssafy.home.model.dto.board.request.BoardUpdateRequestDto;
import com.ssafy.home.model.dto.board.request.BookmarkRequestDto;
import com.ssafy.home.model.dto.board.request.CancelBookmarkRequestDto;
import com.ssafy.home.model.dto.board.response.BoardGetLikeListDto;
import com.ssafy.home.model.dto.board.response.BoardGetListCommentResponseDto;
import com.ssafy.home.model.dto.board.response.BoardGetListResponseDto;
import com.ssafy.home.model.dto.board.response.CheckBoomarksResponseDto;

public interface BoardService {
	public boolean posts(BoardPostRequestDto dto);
	public List<BoardGetListResponseDto>getList();
	public BoardGetListResponseDto getBoard(int boardId);
	public boolean like(int boardId, BoardLikeRequestDto dto);
	public boolean delLike(int boardId, int userId);
	public boolean delBoard(int boardId);
	public boolean view(int boardId, BoardLikeRequestDto dto);
	public boolean comment(int boardId, BoardCommentRequestDto dto);
	public boolean delComment(BoardDeleteCommentRequestDto dto);
	public List<BoardGetListCommentResponseDto> getComment(int boardId);
	public boolean updateBoard(BoardUpdateRequestDto dto, int boardId);
	public boolean updateComment(BoardUpdateCommentDto dto);
	public List<BoardGetListResponseDto> getListAll(int page, int option);
	public int getPageCount();
	public List<BoardGetListResponseDto> getSearchList(int page, String word);
	public int getSearchPageCount(String word);
	public boolean bookmark(int boardId, BookmarkRequestDto bookmarkRequestDto);
	public List<CheckBoomarksResponseDto> checkBoomarks(int boardId);
	public boolean cancelBookmark(int boardId, int userId);
	public List<BoardGetLikeListDto> getLike(int boardId);
}
