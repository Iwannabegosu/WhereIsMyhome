package com.ssafy.home.model.dto.board.response;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class BoardGetListCommentResponseDto {
	private int commentId;
	private int userId;
	private String content;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	
    private String email;
    private String nickname;
    private String profileImgUrl;
}
