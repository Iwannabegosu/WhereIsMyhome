package com.ssafy.home.model.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.home.model.dto.board.request.BoardCommentRequestDto;
import com.ssafy.home.model.dto.board.request.BoardDeleteCommentRequestDto;
import com.ssafy.home.model.dto.board.request.BoardLikeRequestDto;
import com.ssafy.home.model.dto.board.request.BoardPostRequestDto;
import com.ssafy.home.model.dto.board.request.BoardUpdateCommentDto;
import com.ssafy.home.model.dto.board.request.BoardUpdateRequestDto;
import com.ssafy.home.model.dto.board.request.BookmarkRequestDto;
import com.ssafy.home.model.dto.board.request.CancelBookmarkRequestDto;
import com.ssafy.home.model.dto.board.response.BoardGetLikeListDto;
import com.ssafy.home.model.dto.board.response.BoardGetListCommentResponseDto;
import com.ssafy.home.model.dto.board.response.BoardGetListResponseDto;
import com.ssafy.home.model.dto.board.response.CheckBoomarksResponseDto;
import com.ssafy.home.model.entity.Board;
import com.ssafy.home.model.entity.BoardBookmark;
import com.ssafy.home.model.entity.Comment;
import com.ssafy.home.model.entity.Like;
import com.ssafy.home.model.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService{
	@Autowired
	BoardMapper mapper;

	@Override
	public boolean posts(BoardPostRequestDto dto) {
		int n;
		n = mapper.posts(dto.toEntity());
		if(n > 0) return true;
		else return false;
	}

	@Override
	public List<BoardGetListResponseDto> getList() {
		List<Board> list = mapper.getList();
		return list.stream().map(Board::toDto).collect(Collectors.toList());
	}

	@Override
	public BoardGetListResponseDto getBoard(int boardId) {
		Board entity = mapper.getBoard(boardId);
		return entity.toDto();
	}

	@Override
	public boolean like(int boardId, BoardLikeRequestDto dto) {
		int n = mapper.like(boardId, dto.getUserId());
		if(n > 0) return true;
		else return false;
	}

	@Override
	public boolean delLike(int boardId, int userId) {
		int n = mapper.delLike(boardId, userId);
		if(n > 0) return true;
		else return false;
	}

	@Override
	public boolean delBoard(int boardId) {
		int n = mapper.delBoard(boardId);
		if(n > 0) return true;
		else return false;
	}

	@Override
	public boolean view(int boardId, BoardLikeRequestDto dto) {
		int n = mapper.view(boardId, dto.getUserId());
		if(n>0) return true;
		else return false;
	}

	@Override
	public boolean comment(int boardId, BoardCommentRequestDto dto) {
		dto.setBoardId(boardId);
		int n = mapper.comment(dto.toEntity());
		if(n>0) return true;
		else return false;
	}

	@Override
	public boolean delComment(BoardDeleteCommentRequestDto dto) {
		int n = mapper.delComment(dto.getCommentId());
		if(n>0) return true;
		else return false;
	}

	@Override
	public List<BoardGetListCommentResponseDto> getComment(int boardId) {
		List<Comment> list = mapper.getComment(boardId);
		return list.stream().map(Comment::toDto).collect(Collectors.toList());
	}

	@Override
	public boolean updateBoard(BoardUpdateRequestDto dto, int boardId) {
		Board entity = dto.toEntity();
		entity.setBoardId(boardId);
		int n = mapper.updateBoard(entity);
		if(n>0) return true;
		else return false;
	}

	@Override
	public boolean updateComment(BoardUpdateCommentDto dto) {
		int n = mapper.updateComment(dto.toEntity());
		if(n > 0) return true;
		else return false;
	}

	@Override
	public List<BoardGetListResponseDto> getListAll(int page, int option) {
		int count = 15; // 한 페이지 당 몇 개 보여줄지?
		int offset = (page - 1) * count; // 시작점
		List<Board> list = mapper.getListAll(count, option, offset);
		return list.stream().map(Board::toDto).collect(Collectors.toList());
	}

	@Override
	public int getPageCount() {
		return mapper.getPageCount();
	}

	@Override
	public List<BoardGetListResponseDto> getSearchList(int page, String word) {
		int count = 15;
		int offset = (page - 1) * count;
		List<Board> list = mapper.getSearchList(count, word, offset);
		return list.stream().map(Board::toDto).collect(Collectors.toList());
	}

	@Override
	public int getSearchPageCount(String word) {
		return mapper.getSearchPageCount(word);
	}

	@Override
	public boolean bookmark(int boardId, BookmarkRequestDto bookmarkRequestDto) {
		int cnt = mapper.bookmark(boardId, bookmarkRequestDto.getUserId());
		return cnt == 1;
	}

	@Override
	public List<CheckBoomarksResponseDto> checkBoomarks(int boardId) {
		List<BoardBookmark> checkBoomarks = mapper.checkBoomarks(boardId);
		return checkBoomarks.stream().map(BoardBookmark::toCheckBoomarksResponseDto).collect(Collectors.toList());
	}

	@Override
	public boolean cancelBookmark(int boardId, int userId) {
		int cnt = mapper.cancelBookmark(boardId, userId);
		return cnt == 1;
	}

	@Override
	public List<BoardGetLikeListDto> getLike(int boardId) {
		List<Like> list = mapper.getLike(boardId);
		return list.stream().map(Like::toLikeDto).collect(Collectors.toList());
	}
}
