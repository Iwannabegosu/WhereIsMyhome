package com.ssafy.home.model.dto.my.response;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ShowMyPutHouseResponseDto {
	private int putHouseId;
	private String title;
	private String content;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	private int userId;
	private String id;
	private String email;
	private String nickname;
	private String profileImgUrl;
	private int commentCount;
	private int likeCount;
	private int viewCount;
}
