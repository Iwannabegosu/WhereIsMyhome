package com.ssafy.home.security.filter;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Component;

import jakarta.servlet.FilterChain;
import jakarta.servlet.GenericFilter;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class PermitAllFilter extends GenericFilter {

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        // 로그인 요청을 허용할 경로를 리스트에 추가
        List<String> antMatchers = List.of("/user", "/board", "/my", "/puthouse", "/notice", "/map", "/principal", "/ai", "/zzim");

        String uri = request.getRequestURI().replace("/home", "");
        // System.out.println("uri : " + uri);

        // 기본적으로 접근 불가로 설정
        request.setAttribute("isPermitAll", false);
        
        for (String antMatcher : antMatchers) {
            if (uri.startsWith(antMatcher)) {
                request.setAttribute("isPermitAll", true);
                break; // 하나라도 매치되면 더 이상 체크할 필요 없음
            }
        }

        filterChain.doFilter(request, response);
    }
}
