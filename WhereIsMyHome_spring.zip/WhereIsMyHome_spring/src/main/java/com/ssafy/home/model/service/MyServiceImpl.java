package com.ssafy.home.model.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.ssafy.home.model.dto.my.request.DeleteMyPutHouseRequestDto;
import com.ssafy.home.model.dto.my.request.MyPutHousePaginationRequestDto;
import com.ssafy.home.model.dto.my.request.NicknameCheckRequestDto;
import com.ssafy.home.model.dto.my.request.PasswordCheckRequestDto;
import com.ssafy.home.model.dto.my.request.SearchMyPutHousePaginationRequestDto;
import com.ssafy.home.model.dto.my.request.SearchMyPutHousesRequestDto;
import com.ssafy.home.model.dto.my.request.ShowInfoRequestDto;
import com.ssafy.home.model.dto.my.request.ShowMyPutHouseRequestDto;
import com.ssafy.home.model.dto.my.request.UpdateInfoRequestDto;
import com.ssafy.home.model.dto.my.response.SearchMyPutHousesResponseDto;
import com.ssafy.home.model.dto.my.response.ShowInfoResponseDto;
import com.ssafy.home.model.dto.my.response.ShowMyPutHouseResponseDto;
import com.ssafy.home.model.entity.PutHouse;
import com.ssafy.home.model.entity.User;
import com.ssafy.home.model.mapper.MyMapper;

@Service
public class MyServiceImpl implements MyService {
	
	@Autowired
	MyMapper mapper;
	
	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	@Override
	public ShowInfoResponseDto showInfo(int userId) {
		User user = mapper.showInfo(userId);
		if(user == null) return null;
		return user.toShowInfoResponseDto();
	}
	
	@Override
	public boolean nicknamecheck(String nickname) {
		User user = mapper.nicknamecheck(nickname);
		if(user == null) return false;
		return true;
	}

	@Override
	public boolean updateInfo(UpdateInfoRequestDto updateRequestDto) {
		int cnt;
		if(updateRequestDto.getPassword() == "" || updateRequestDto.getPassword() == null) {
			cnt = mapper.updateInfoWithoutPassword(updateRequestDto.toEntity()); // 비밀번호를 제외한 정보 변경
		}else {
			cnt = mapper.updateInfo(updateRequestDto.toEntity(passwordEncoder)); // 비밀번호를 포함한 정보 변경
		}
		return cnt == 1;
	}

	@Override
	public boolean passwordcheck(PasswordCheckRequestDto passwordCheckRequestDto) {
		User user = mapper.findUserByUserId(passwordCheckRequestDto.getUserId());
		return passwordEncoder.matches(passwordCheckRequestDto.getPassword(), user.getPassword());
	}

	@Override
	public List<ShowMyPutHouseResponseDto> showMyPutHouses(ShowMyPutHouseRequestDto showMyPutHouseRequestDto, int page) {
		int count = 3; // 한 페이지에 몇개의 데이터를 보여주는가
		int offset = (page - 1) * count;
		List<PutHouse> showMyPutHouses = mapper.showMyPutHouses(offset, count, showMyPutHouseRequestDto.getUserId());
		return showMyPutHouses.stream().map(PutHouse::toShowMyPutHouseResponseDto).collect(Collectors.toList());
	}

	@Override
	public int myPutHousePagination(MyPutHousePaginationRequestDto myPutHousePaginationRequestDto) {
		return mapper.myPutHousePagination(myPutHousePaginationRequestDto.getUserId());
	}

	@Override
	public List<SearchMyPutHousesResponseDto> searchMyPutHouses(int page, String word, SearchMyPutHousesRequestDto SearchMyPutHousesRequestDto) {
		int count = 3;
		int offset = (page - 1) * count;
		List<PutHouse> searchMyPutHouses = mapper.searchMyPutHouses(offset, count, word, SearchMyPutHousesRequestDto.getUserId());
		return searchMyPutHouses.stream().map(PutHouse::toSearchMyPutHousesResponseDto).collect(Collectors.toList());
	}

	@Override
	public int searchMyPutHousePagination(SearchMyPutHousePaginationRequestDto searchMyPutHousePaginationRequestDto) {
		return mapper.searchMyPutHousePagination(searchMyPutHousePaginationRequestDto.getWord(), searchMyPutHousePaginationRequestDto.getUserId());
	}

	@Override
	public boolean deleteMyPutHouse(DeleteMyPutHouseRequestDto deleteMyPutHouseRequestDto) {
		int cnt = mapper.deleteMyPutHouse(deleteMyPutHouseRequestDto.getPutHouseId());
		return cnt == 1;
	}

	

}
