package com.ssafy.home.model.entity;

import java.time.LocalDateTime;

import com.ssafy.home.model.dto.board.request.BoardUpdateRequestDto;
import com.ssafy.home.model.dto.board.response.BoardGetListResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Board {
	private int boardId;
	private String title;
	private String content;
	private int userId;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	
	private int commentCount;
	private int likeCount;
	private int viewCount;
	
	public Comment comment;
	public Like like;
	public View view;
	public User user;
	
	public BoardGetListResponseDto toDto() {
		return BoardGetListResponseDto
				.builder()
				.boardId(boardId)
				.title(title)
				.content(content)
				.userId(userId)
				.createDate(createDate)
				.updateDate(updateDate)
				.commentCount(commentCount)
				.likeCount(likeCount)
				.viewCount(viewCount)
				.id(user.getId())
				.email(user.getEmail())
				.profileImgUrl(user.getProfileImgUrl())
				.nickname(user.getNickname())
				.build();
	}
	
}
