package com.ssafy.home.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ssafy.home.model.dto.map.request.LocationRequestDto;
import com.ssafy.home.model.entity.Apt;
import com.ssafy.home.model.entity.Boundary;
import com.ssafy.home.model.entity.Dong;
import com.ssafy.home.model.entity.Sigungu;

@Mapper
public interface AptMapper {
	public List<Apt> listAll();
	public List<Apt> location(LocationRequestDto dto);
	public List<Boundary> cluster(LocationRequestDto dto);
	public List<Sigungu> sigungu(LocationRequestDto dto);
	public List<Dong> dong(LocationRequestDto dto);
	public List<Apt> search(String word);
}
