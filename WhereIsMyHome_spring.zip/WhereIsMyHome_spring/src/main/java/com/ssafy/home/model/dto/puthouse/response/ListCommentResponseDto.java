package com.ssafy.home.model.dto.puthouse.response;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ListCommentResponseDto {
	private int putHouseCommentId;
	private int putHouseId;
	private int userId;
	private String content;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	
	private String id;
	private String email;
	private String nickname;
	private String profileImgUrl;
}
