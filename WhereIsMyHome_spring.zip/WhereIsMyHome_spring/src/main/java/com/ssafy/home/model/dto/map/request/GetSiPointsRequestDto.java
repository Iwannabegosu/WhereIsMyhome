package com.ssafy.home.model.dto.map.request;

import lombok.Data;

@Data
public class GetSiPointsRequestDto {
	private String swLat;
	private String swLng;
	private String neLat;
	private String neLng;
}
