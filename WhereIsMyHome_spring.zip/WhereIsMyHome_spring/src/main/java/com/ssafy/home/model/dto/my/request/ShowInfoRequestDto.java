package com.ssafy.home.model.dto.my.request;

import lombok.Data;

@Data
public class ShowInfoRequestDto {
	private int userId;
}
