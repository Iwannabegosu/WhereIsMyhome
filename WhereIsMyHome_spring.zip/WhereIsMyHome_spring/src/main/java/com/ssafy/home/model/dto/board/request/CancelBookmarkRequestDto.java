package com.ssafy.home.model.dto.board.request;

import lombok.Data;

@Data
public class CancelBookmarkRequestDto {
	private int userId;
}
