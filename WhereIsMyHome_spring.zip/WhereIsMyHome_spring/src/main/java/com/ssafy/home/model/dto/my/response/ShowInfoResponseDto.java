package com.ssafy.home.model.dto.my.response;

import com.ssafy.home.model.entity.RoleRegister;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ShowInfoResponseDto {
	private int userId;
    private String id;
    private String email;
    private String nickname;
    private String profileImgUrl;
}
