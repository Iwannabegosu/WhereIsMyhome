package com.ssafy.home.model.dto.board.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BoardGetLikeListDto {
	private int userId;
	private int likeId;
	private int boardId;
}
