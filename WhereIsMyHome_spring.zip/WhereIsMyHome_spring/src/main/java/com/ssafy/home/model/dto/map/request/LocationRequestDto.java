package com.ssafy.home.model.dto.map.request;

import com.ssafy.home.model.entity.Apt;

import lombok.Data;

@Data
public class LocationRequestDto {
	private String swLat;
	private String swLng;
	private String neLat;
	private String neLng;
}
