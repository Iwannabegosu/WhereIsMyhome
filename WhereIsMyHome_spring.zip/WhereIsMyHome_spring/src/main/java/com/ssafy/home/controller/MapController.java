package com.ssafy.home.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.home.model.dto.map.request.GetSiPointsRequestDto;
import com.ssafy.home.model.dto.map.request.LocationRequestDto;
import com.ssafy.home.model.service.MapService;

import jakarta.websocket.server.PathParam;

@RestController
@RequestMapping("/map")
public class MapController {
	
	@Autowired
	MapService mapService;
	
	@GetMapping("")
	public ResponseEntity<?> listAll(){
		return ResponseEntity.ok(mapService.listAll());
	}
	
	@PostMapping("/location")
	public ResponseEntity<?> location(@RequestBody LocationRequestDto dto){
		return ResponseEntity.ok(mapService.location(dto));
	}
	
	@PostMapping("/cluster")
	public ResponseEntity<?> cluster(@RequestBody LocationRequestDto dto){
		return ResponseEntity.ok(mapService.cluster(dto));
	}
	
	@PostMapping("/sigungu")
	public ResponseEntity<?> sigungu(@RequestBody LocationRequestDto dto){
		return ResponseEntity.ok(mapService.sigungu(dto));
	}
	
	@PostMapping("/dong")
	public ResponseEntity<?> dong(@RequestBody LocationRequestDto dto){
		return ResponseEntity.ok(mapService.dong(dto));
	}
	
	@GetMapping("/{word}")
	public ResponseEntity<?> search(@PathVariable("word") String word){
		return ResponseEntity.ok(mapService.search(word));
	}
	
	
}
