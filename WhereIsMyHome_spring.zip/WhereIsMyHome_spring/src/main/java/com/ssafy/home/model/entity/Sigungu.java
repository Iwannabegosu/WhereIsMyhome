package com.ssafy.home.model.entity;

import com.ssafy.home.model.dto.map.response.SigunguResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Sigungu {
	private int sigunguId;
	private int average;
	private String sigunguName;
	private String lat;
	private String lng;
	private String className;
	
	public SigunguResponseDto toSigunguDto() {
		double number = (double)average;
		double result = number/10000;
		result = Math.round(result * 10.0) / 10.0;
		return SigunguResponseDto
				.builder()
				.sigunguId(sigunguId)
				.average(result)
				.sigunguName(sigunguName)
				.lat(Double.parseDouble(lat))
				.lng(Double.parseDouble(lng))
				.className(className)
				.build();
	}
}
