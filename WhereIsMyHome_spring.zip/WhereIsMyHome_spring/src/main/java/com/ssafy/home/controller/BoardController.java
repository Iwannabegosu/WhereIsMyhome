package com.ssafy.home.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.home.model.dto.board.request.BoardCommentRequestDto;
import com.ssafy.home.model.dto.board.request.BoardDeleteCommentRequestDto;
import com.ssafy.home.model.dto.board.request.BoardLikeRequestDto;
import com.ssafy.home.model.dto.board.request.BoardPostRequestDto;
import com.ssafy.home.model.dto.board.request.BoardUpdateCommentDto;
import com.ssafy.home.model.dto.board.request.BoardUpdateRequestDto;
import com.ssafy.home.model.dto.board.request.BookmarkRequestDto;
import com.ssafy.home.model.dto.board.request.CancelBookmarkRequestDto;
import com.ssafy.home.model.service.BoardService;

@RestController
@RequestMapping("/board")
public class BoardController {
	@Autowired
	BoardService boardService;
	// C 
	// 게시물 작성
	@PostMapping("/posts")
	public ResponseEntity<?> posts(@RequestBody BoardPostRequestDto boardPostRequestDto){
		return ResponseEntity.ok(boardService.posts(boardPostRequestDto));
	}
	
	// 게시물 좋아요 등록
	@PostMapping("/{boardId}/like")
	public ResponseEntity<?> like(@PathVariable("boardId") int boardId,
			                      @RequestBody BoardLikeRequestDto dto){
		return ResponseEntity.ok(boardService.like(boardId, dto));
	}
	
	// 게시물 조회수 등록
	@PostMapping("/{boardId}")
	public ResponseEntity<?> view(@PathVariable("boardId") int boardId,
			                      @RequestBody BoardLikeRequestDto dto){
		return ResponseEntity.ok(boardService.view(boardId, dto)); 
	}
	
	 //게시물 댓글 작성
	@PostMapping("/{boardId}/comment")
	public ResponseEntity<?> comment(@PathVariable("boardId") int boardId,
			                         @RequestBody BoardCommentRequestDto dto){
		return ResponseEntity.ok(boardService.comment(boardId, dto));
	 }
	
	// D
	// 게시물 좋아요 취소
	@DeleteMapping("/{boardId}/like/{userId}")
	public ResponseEntity<?> delLike(@PathVariable("boardId") int boardId, @PathVariable("userId") int userId){
		System.out.println("좋아요 취소");
		return ResponseEntity.ok(boardService.delLike(boardId, userId));
	}
	
	// 게시물 삭제
	@DeleteMapping("/{boardId}")
	public ResponseEntity<?> delBoard(@PathVariable("boardId") int boardId){
		return ResponseEntity.ok(boardService.delBoard(boardId));
	}
	
	// 게시물 댓글 삭제
	@DeleteMapping("/{boardId}/comment")
	public ResponseEntity<?> delComment(@RequestBody BoardDeleteCommentRequestDto dto){
		return ResponseEntity.ok(boardService.delComment(dto));
	}
	
	// R
	// 게시물 리스트 조회
//	@GetMapping("")
//	public ResponseEntity<?> getList(){
//		return ResponseEntity.ok(boardService.getList());
//	}
	
	//좋아요 조회
	@GetMapping("{boardId}/like")
	public ResponseEntity<?> getLike(@PathVariable("boardId") int boardId){
		return ResponseEntity.ok(boardService.getLike(boardId));
	}
	
	// 게시물 리스트 조회(페이지 네이션)
	// option = 0 : 최신순, option = 1 트랜딩
	@GetMapping("")
	public ResponseEntity<?> getListAll(@RequestParam int page, @RequestParam int option){
		return ResponseEntity.ok(boardService.getListAll(page, option));
		
	}
	
	// 총 게시물 게수
	@GetMapping("/pagination")
	public ResponseEntity<?> getPageCount(){
		return ResponseEntity.ok(boardService.getPageCount());
	}
	
	// 게시물 검색
	@GetMapping("/search")
	public ResponseEntity<?> getSearchList(@RequestParam int page, @RequestParam String word){
		System.out.println(page +  word);
		return ResponseEntity.ok(boardService.getSearchList(page, word));
	}
	
	// 검색 후 페이지 개수
	@GetMapping("/search/pagination")
	public ResponseEntity<?> getSearchPageCount(@RequestParam String word){
		System.out.println(word);
		return ResponseEntity.ok(boardService.getSearchPageCount(word));
	}
	
	// 게시물 조회(단건)
	@GetMapping("/{boardId}")
	public ResponseEntity<?> getBoard(@PathVariable("boardId") int boardId){
		return ResponseEntity.ok(boardService.getBoard(boardId));
	}
	
	// 게시물 댓글 조회
	@GetMapping("/{boardId}/comment")
	public ResponseEntity<?> getComment(@PathVariable("boardId") int boardId){
		return ResponseEntity.ok(boardService.getComment(boardId));
	}
	
	
	// U
	// 게시물 수정
	@PutMapping("/{boardId}/update")
	public ResponseEntity<?> updateBoard(@PathVariable("boardId") int boardId,
									     @RequestBody BoardUpdateRequestDto dto){
		return ResponseEntity.ok(boardService.updateBoard(dto, boardId));
	}
	
	// 게시물 댓글 수정
	@PutMapping("/{boardId}/comment/update")
	public ResponseEntity<?> updateComment(@PathVariable("boardId") int boardId,
			 							   @RequestBody BoardUpdateCommentDto dto){
		return ResponseEntity.ok(boardService.updateComment(dto));
	}
	
	// 북마크 등록
	@PostMapping("/{boardId}/bookmark")
	public ResponseEntity<?> bookmark (@PathVariable("boardId") int boardId, @RequestBody BookmarkRequestDto bookmarkRequestDto) {
		return ResponseEntity.ok(boardService.bookmark(boardId, bookmarkRequestDto));
	}
	
	// 북마크 조회
	@GetMapping("/{boardId}/check")
	public ResponseEntity<?> checkBoomarks (@PathVariable("boardId") int boardId) {
		return ResponseEntity.ok(boardService.checkBoomarks(boardId));
	}
	
	// 북마크 취소
	@DeleteMapping("/{boardId}/bookmark/{userId}")
	public ResponseEntity<?> cancelBookmark(@PathVariable("boardId") int boardId, @PathVariable("userId") int userId) {
		return ResponseEntity.ok(boardService.cancelBookmark(boardId, userId));
	}
}
