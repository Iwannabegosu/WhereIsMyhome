package com.ssafy.home.model.dto.my.request;

import lombok.Data;

@Data
public class PasswordCheckRequestDto {
	private int userId;
	private String password;
}
