package com.ssafy.home.model.service;

import java.util.List;

import com.ssafy.home.model.dto.my.request.DeleteMyPutHouseRequestDto;
import com.ssafy.home.model.dto.my.request.MyPutHousePaginationRequestDto;
import com.ssafy.home.model.dto.my.request.NicknameCheckRequestDto;
import com.ssafy.home.model.dto.my.request.PasswordCheckRequestDto;
import com.ssafy.home.model.dto.my.request.SearchMyPutHousePaginationRequestDto;
import com.ssafy.home.model.dto.my.request.SearchMyPutHousesRequestDto;
import com.ssafy.home.model.dto.my.request.ShowInfoRequestDto;
import com.ssafy.home.model.dto.my.request.ShowMyPutHouseRequestDto;
import com.ssafy.home.model.dto.my.request.UpdateInfoRequestDto;
import com.ssafy.home.model.dto.my.response.SearchMyPutHousesResponseDto;
import com.ssafy.home.model.dto.my.response.ShowInfoResponseDto;
import com.ssafy.home.model.dto.my.response.ShowMyPutHouseResponseDto;

public interface MyService {
	public ShowInfoResponseDto showInfo(int userId);
	public boolean nicknamecheck(String nickname);
	public boolean updateInfo(UpdateInfoRequestDto updateRequestDto);
	public boolean passwordcheck(PasswordCheckRequestDto passwordCheckRequestDto);
	
	public List<ShowMyPutHouseResponseDto> showMyPutHouses(ShowMyPutHouseRequestDto showMyPutHouseRequestDto, int page);
	public int myPutHousePagination(MyPutHousePaginationRequestDto myPutHousePaginationRequestDto);
	public List<SearchMyPutHousesResponseDto> searchMyPutHouses(int page, String word, SearchMyPutHousesRequestDto SearchMyPutHousesRequestDto);
	public int searchMyPutHousePagination(SearchMyPutHousePaginationRequestDto searchMyPutHousePaginationRequestDto);
	public boolean deleteMyPutHouse(DeleteMyPutHouseRequestDto deleteMyPutHouseRequestDto);
}
