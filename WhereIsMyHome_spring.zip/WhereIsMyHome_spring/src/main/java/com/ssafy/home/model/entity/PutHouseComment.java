package com.ssafy.home.model.entity;

import java.time.LocalDateTime;

import com.ssafy.home.model.dto.puthouse.response.ListCommentResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PutHouseComment {
	private int putHouseCommentId;
	private int putHouseId;
	private int userId;
	private String content;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	
	private User user;
	
	public ListCommentResponseDto toListCommentResponseDto() {
		return ListCommentResponseDto
				.builder()
				.putHouseCommentId(putHouseCommentId)
				.putHouseId(putHouseId)
				.userId(userId)
				.content(content)
				.createDate(createDate)
				.updateDate(updateDate)
				.id(user.getId())
				.email(user.getEmail())
				.nickname(user.getNickname())
				.profileImgUrl(user.getProfileImgUrl())
				.build();
	}
}
