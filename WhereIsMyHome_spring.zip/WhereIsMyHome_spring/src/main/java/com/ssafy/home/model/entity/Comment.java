package com.ssafy.home.model.entity;
import java.time.LocalDateTime;

import com.ssafy.home.model.dto.board.response.BoardGetListCommentResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Comment {
	private int commentId;
	private int boardId;
	private int userId;
	private String content;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	
	private User user;
	public BoardGetListCommentResponseDto toDto() {
		return BoardGetListCommentResponseDto
				.builder()
				.commentId(commentId)
				.userId(userId)
				.content(content)
				.createDate(createDate)
				.updateDate(updateDate)
				.email(user.getEmail())
				.nickname(user.getNickname())
				.profileImgUrl(user.getProfileImgUrl())
				.build();
	}
}
