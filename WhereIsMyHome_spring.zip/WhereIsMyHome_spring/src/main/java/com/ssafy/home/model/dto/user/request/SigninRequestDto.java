package com.ssafy.home.model.dto.user.request;

import lombok.Data;

@Data
public class SigninRequestDto {
	private String id;
	private String password;
}
