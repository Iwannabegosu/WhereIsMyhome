package com.ssafy.home.model.dto.user.request;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.ssafy.home.model.entity.User;

import lombok.Data;

@Data
public class SignupRequestDto {
	private String id;
	private String password;
	private String email;
	private String nickname;
	private String profileImgUrl;
	
	public User toEntity(BCryptPasswordEncoder passwordEncoder) {
		return User
				.builder()
				.userId(0)
				.id(id)
				.password(passwordEncoder.encode(password))
				.email(email)
				.nickname(nickname)
				.profileImgUrl(profileImgUrl)
				.build(); 
	}
}
