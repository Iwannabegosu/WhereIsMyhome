package com.ssafy.home.model.dto.puthouse.request;

import com.ssafy.home.model.entity.PutHouseComment;

import lombok.Data;

@Data
public class UpdateCommentRequestDto {
	private int putHouseCommentId;
	private int userId;
	private String content;
	
	public PutHouseComment toEntity() {
		return PutHouseComment
				.builder()
				.putHouseCommentId(putHouseCommentId)
				.userId(userId)
				.content(content)
				.build();
	}
}
