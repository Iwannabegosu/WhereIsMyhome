package com.ssafy.home.model.entity;

import java.time.LocalDateTime;

import com.ssafy.home.model.dto.my.response.SearchMyPutHousesResponseDto;
import com.ssafy.home.model.dto.my.response.ShowMyPutHouseResponseDto;
import com.ssafy.home.model.dto.puthouse.response.DetailResponseDto;
import com.ssafy.home.model.dto.puthouse.response.ListAllResponseDto;
import com.ssafy.home.model.dto.puthouse.response.SearchListResponseDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PutHouse {
	private int putHouseId;
	private String title;
	private String content;
	private int userId;
	private LocalDateTime createDate;
	private LocalDateTime updateDate;
	

	public User user;
	public PutHouseComment putHouseComment;
	public PutHouseLike putHouseLike;
	public PutHouseView putHouseView;
	
	private int commentCount;
	private int likeCount;
	private int viewCount;
	
	public ListAllResponseDto toListAllResponseDto() {
		return ListAllResponseDto
				.builder()
				.putHouseId(putHouseId)
				.title(title)
				.content(content)
				.userId(userId)
				.createDate(createDate)
				.updateDate(updateDate)
				.id(user.getId())
				.email(user.getEmail())
				.nickname(user.getNickname())
				.profileImgUrl(user.getProfileImgUrl())
				.commentCount(commentCount)
				.likeCount(likeCount)
				.viewCount(viewCount)
				.build();
	}
	
	public DetailResponseDto toDetailResponseDto() {
		return DetailResponseDto
				.builder()
				.putHouseId(putHouseId)
				.title(title)
				.content(content)
				.userId(userId)
				.createDate(createDate)
				.updateDate(updateDate)
				.id(user.getId())
				.email(user.getEmail())
				.nickname(user.getNickname())
				.profileImgUrl(user.getProfileImgUrl())
				.commentCount(commentCount)
				.likeCount(likeCount)
				.viewCount(viewCount)
				.build();
	}
	
	public SearchListResponseDto toSearchListResponseDto() {
		return SearchListResponseDto
				.builder()
				.putHouseId(putHouseId)
				.title(title)
				.content(content)
				.userId(userId)
				.createDate(createDate)
				.updateDate(updateDate)
				.id(user.getId())
				.email(user.getEmail())
				.nickname(user.getNickname())
				.profileImgUrl(user.getProfileImgUrl())
				.commentCount(commentCount)
				.likeCount(likeCount)
				.viewCount(viewCount)
				.build();
	}
	
	public ShowMyPutHouseResponseDto toShowMyPutHouseResponseDto() {
		return ShowMyPutHouseResponseDto
				.builder()
				.putHouseId(putHouseId)
				.title(title)
				.content(content)
				.userId(userId)
				.createDate(createDate)
				.updateDate(updateDate)
				.id(user.getId())
				.email(user.getEmail())
				.nickname(user.getNickname())
				.profileImgUrl(user.getProfileImgUrl())
				.commentCount(commentCount)
				.likeCount(likeCount)
				.viewCount(viewCount)
				.build();
	}
	
	public SearchMyPutHousesResponseDto toSearchMyPutHousesResponseDto() {
		return SearchMyPutHousesResponseDto
				.builder()
				.putHouseId(putHouseId)
				.title(title)
				.content(content)
				.userId(userId)
				.createDate(createDate)
				.updateDate(updateDate)
				.id(user.getId())
				.email(user.getEmail())
				.nickname(user.getNickname())
				.profileImgUrl(user.getProfileImgUrl())
				.commentCount(commentCount)
				.likeCount(likeCount)
				.viewCount(viewCount)
				.build();
	}
}
