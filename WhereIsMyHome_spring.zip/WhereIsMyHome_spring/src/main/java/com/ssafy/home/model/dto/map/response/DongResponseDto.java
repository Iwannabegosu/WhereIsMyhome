package com.ssafy.home.model.dto.map.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DongResponseDto {
	private int dongId;
	private double average;
	private String dongName;
	private double lat;
	private double lng;
	private String className;
}
