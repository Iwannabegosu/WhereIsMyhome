package com.ssafy.home.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ssafy.home.model.entity.Notice;

@Mapper
public interface NoticeMapper {
	public int post(Notice entity);
	public int delNotice(int noticeId);
	public List<Notice> getListAll(@Param("count") int count, 
								   @Param("offset") int offset);
	public int getNoticeCount();
	public List<Notice> getSearchList(@Param("count") int count,
									  @Param("offset") int offset,
									  @Param("word") String word);
	public int getSearchCount(String word);
	public Notice getNotice(int noticeId);
	public int updateNotice(Notice entity);
	public List<Notice> descNotice();
}
